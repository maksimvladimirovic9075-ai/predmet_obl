Option Compare Database
Option Explicit

Public Function NavOpenForm(ByVal strName As String)
    On Error Resume Next
    DoCmd.OpenForm strName, acNormal
End Function

Public Function NavOpenReport(ByVal strName As String)
    On Error Resume Next
    DoCmd.OpenReport strName, acViewPreview
End Function

Public Function NavOpenQuery(ByVal strName As String)
    On Error Resume Next
    DoCmd.OpenQuery strName, acViewNormal, acReadOnly
End Function

Public Function NavCloseForm(ByVal strName As String)
    On Error Resume Next
    DoCmd.Close acForm, strName, acSaveYes
End Function

Public Function NavRebuildAnalytics()
    On Error Resume Next
    DoCmd.Close acForm, ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1099), acSaveNo
    BuildFormAnalytics
    DoCmd.OpenForm ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1099), acNormal
End Function

Private Sub SafeDeleteObject(ByVal objType As Long, ByVal strName As String)
    On Error Resume Next
    DoCmd.Close objType, strName, acSaveNo
    DoCmd.DeleteObject objType, strName
    Err.Clear
End Sub

Private Sub EnsureFormHeaderFooter(ByRef frm As Form, ByVal tmpName As String)
    Dim h As Long
    DoCmd.SelectObject acForm, tmpName
    On Error Resume Next
    h = frm.Section(acHeader).Height
    If Err.Number <> 0 Then
        Err.Clear
        DoCmd.RunCommand acCmdFormHdrFtr
    End If
    On Error GoTo 0
End Sub

Private Sub EnsureReportHeaderFooter(ByRef rpt As Report, ByVal tmpName As String)
    Dim h As Long
    DoCmd.SelectObject acReport, tmpName
    On Error Resume Next
    h = rpt.Section(acHeader).Height
    If Err.Number <> 0 Then
        Err.Clear
        DoCmd.RunCommand acCmdReportHdrFtr
    End If
    On Error GoTo 0
End Sub

Private Sub SaveAndRenameForm(ByVal tmpName As String, ByVal targetName As String)
    DoCmd.Save acForm, tmpName
    DoCmd.Close acForm, tmpName, acSaveYes
    If tmpName <> targetName Then
        DoCmd.Rename targetName, acForm, tmpName
    End If
End Sub

Private Sub SaveAndRenameReport(ByVal tmpName As String, ByVal targetName As String)
    DoCmd.Save acReport, tmpName
    DoCmd.Close acReport, tmpName, acSaveYes
    If tmpName <> targetName Then
        DoCmd.Rename targetName, acReport, tmpName
    End If
End Sub

Private Function AddFormLabel(ByVal fName As String, ByVal sec As Long, ByVal cap As String, _
    ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal fSize As Long, ByVal isBold As Boolean, ByVal fColor As Long) As Control
    Dim ctl As Control
    Set ctl = CreateFormControl(fName, acLabel, sec, "", "", l, t, w, h)
    ctl.Caption = cap
    ctl.FontName = "Segoe UI"
    ctl.FontSize = fSize
    ctl.FontBold = isBold
    ctl.ForeColor = fColor
    ctl.BackStyle = 0
    Set AddFormLabel = ctl
End Function

Private Function AddFormBox(ByVal fName As String, ByVal sec As Long, _
    ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal bgColor As Long, ByVal borderColor As Long) As Control
    Dim ctl As Control
    Set ctl = CreateFormControl(fName, acRectangle, sec, "", "", l, t, w, h)
    ctl.BackStyle = 1
    ctl.BackColor = bgColor
    ctl.BorderStyle = 1
    ctl.BorderColor = borderColor
    Set AddFormBox = ctl
End Function

Private Function AddFormButton(ByVal fName As String, ByVal sec As Long, ByVal cap As String, _
    ByVal onClickExpr As String, ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal bgColor As Long, ByVal fColor As Long) As Control
    Dim ctl As Control
    Set ctl = CreateFormControl(fName, acCommandButton, sec, "", "", l, t, w, h)
    ctl.Caption = cap
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    ctl.FontBold = True
    ctl.OnClick = onClickExpr
    On Error Resume Next
    ctl.UseTheme = False
    ctl.BackColor = bgColor
    ctl.ForeColor = fColor
    ctl.BorderColor = bgColor
    On Error GoTo 0
    Set AddFormButton = ctl
End Function

Private Function AddFormField(ByVal fName As String, ByVal sec As Long, ByVal lblText As String, _
    ByVal colSource As String, ByVal lLbl As Long, ByVal wLbl As Long, _
    ByVal lTxt As Long, ByVal wTxt As Long, ByVal t As Long, ByVal h As Long) As Control
    Dim lbl As Control
    Dim txt As Control
    If Len(lblText) > 0 Then
        Set lbl = AddFormLabel(fName, sec, lblText, lLbl, t + 30, wLbl, h, 10, True, RGB(30, 41, 59))
    End If
    Set txt = CreateFormControl(fName, acTextBox, sec, "", colSource, lTxt, t, wTxt, h)
    txt.FontName = "Segoe UI"
    txt.FontSize = 10
    txt.ForeColor = RGB(15, 23, 42)
    txt.BorderColor = RGB(148, 163, 184)
    txt.BorderStyle = 1
    Set AddFormField = txt
End Function

Private Function AddReportLabel(ByVal rName As String, ByVal sec As Long, ByVal cap As String, _
    ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal fSize As Long, ByVal isBold As Boolean, ByVal fColor As Long) As Control
    Dim ctl As Control
    Set ctl = CreateReportControl(rName, acLabel, sec, "", "", l, t, w, h)
    ctl.Caption = cap
    ctl.FontName = "Segoe UI"
    ctl.FontSize = fSize
    ctl.FontBold = isBold
    ctl.ForeColor = fColor
    ctl.BackStyle = 0
    Set AddReportLabel = ctl
End Function

Private Function AddReportText(ByVal rName As String, ByVal sec As Long, ByVal src As String, _
    ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal fSize As Long, ByVal isBold As Boolean, ByVal fColor As Long, ByVal alignCode As Byte) As Control
    Dim ctl As Control
    Set ctl = CreateReportControl(rName, acTextBox, sec, "", "", l, t, w, h)
    ctl.ControlSource = src
    ctl.FontName = "Segoe UI"
    ctl.FontSize = fSize
    ctl.FontBold = isBold
    ctl.ForeColor = fColor
    ctl.BackStyle = 0
    ctl.BorderStyle = 0
    ctl.TextAlign = alignCode
    Set AddReportText = ctl
End Function

Private Function AddReportBox(ByVal rName As String, ByVal sec As Long, _
    ByVal l As Long, ByVal t As Long, ByVal w As Long, ByVal h As Long, _
    ByVal bgColor As Long, ByVal borderColor As Long) As Control
    Dim ctl As Control
    Set ctl = CreateReportControl(rName, acRectangle, sec, "", "", l, t, w, h)
    ctl.BackStyle = 1
    ctl.BackColor = bgColor
    ctl.BorderStyle = 1
    ctl.BorderColor = borderColor
    Set AddReportBox = ctl
End Function

Public Sub BuildAllQueries()
    Dim db As Object
    Dim qdf As Object
    Dim strSQL As String
    Dim strName As String
    Set db = CurrentDb
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_1_" & ChrW(1057) & _
        ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "], [" & _
        ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].["
    strSQL = strSQL & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100) & "], [" & _
        ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1050) & _
        ChrW(1072) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1077) & ChrW(1090) & "_" & ChrW(1082) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103)
    strSQL = strSQL & "].[" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "] AS [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1088) & ChrW(1091) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1100) & "], ["
    strSQL = strSQL & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & "] & ' ' & [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1048) & ChrW(1084) & ChrW(1103) & "] & "
    strSQL = strSQL & "' ' & [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & _
        ChrW(1086) & "] AS [" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "], "
    strSQL = strSQL & "[" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & "_" & ChrW(1088) & ChrW(1086) & _
        ChrW(1078) & ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "], [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1055) & _
        ChrW(1086) & ChrW(1083) & "], ["
    strSQL = strSQL & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & "_" & _
        ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1040) & ChrW(1076) & ChrW(1088) & ChrW(1077) & ChrW(1089)
    strSQL = strSQL & "] FROM ([" & ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "] INNER JOIN [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] ON [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1080)
    strSQL = strSQL & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "] = [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & "_" & ChrW(1088) & _
        ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & ChrW(1086)
    strSQL = strSQL & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "]) INNER JOIN [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "] ON [" & ChrW(1050) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086)
    strSQL = strSQL & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & _
        "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072) & "] ORDER BY ["
    strSQL = strSQL & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1055) & _
        ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & ChrW(1100) & _
        "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089)
    strSQL = strSQL & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & _
        ChrW(1103) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_2_" & ChrW(1055) & _
        ChrW(1086) & ChrW(1080) & ChrW(1089) & ChrW(1082) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "], [" & _
        ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].["
    strSQL = strSQL & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100) & "], [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "].[" & _
        ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103) & "] AS [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1085) & ChrW(1099)
    strSQL = strSQL & ChrW(1081) & "_" & ChrW(1088) & ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & ChrW(1086) & _
        ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "], [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1060) & _
        ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & "], [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082)
    strSQL = strSQL & ChrW(1080) & "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "], [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1090) & _
        ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & "], [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1044) & _
        ChrW(1072)
    strSQL = strSQL & ChrW(1090) & ChrW(1072) & "_" & ChrW(1088) & ChrW(1086) & ChrW(1078) & ChrW(1076) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1103) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & _
        ChrW(1092) & ChrW(1086) & ChrW(1085) & "_" & ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "] FR"
    strSQL = strSQL & "OM ([" & ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "] INNER JOIN [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] ON [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103)
    strSQL = strSQL & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "] = [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1082) & ChrW(1083) & "_" & ChrW(1088) & ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077)
    strSQL = strSQL & ChrW(1083) & ChrW(1103) & "]) INNER JOIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1080) & "] ON [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083)
    strSQL = strSQL & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "] WHERE ([" & _
        ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099)
    strSQL = strSQL & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & _
        ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & _
        "] = [" & ChrW(1042) & ChrW(1074) & ChrW(1077) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & " (" & ChrW(1085) & _
        ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1080) & ChrW(1084) & ChrW(1077)
    strSQL = strSQL & ChrW(1088) & " 9" & ChrW(1040) & ") " & ChrW(1080) & ChrW(1083) & ChrW(1080) & " " & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1072) & ChrW(1074) & ChrW(1100) & ChrW(1090) & ChrW(1077) & _
        " " & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1090) & ChrW(1099) & ChrW(1084) & ":] OR [" & _
        ChrW(1042) & ChrW(1074) & ChrW(1077) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & " " & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089)
    strSQL = strSQL & " (" & ChrW(1085) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1080) & ChrW(1084) & ChrW(1077) & _
        ChrW(1088) & " 9" & ChrW(1040) & ") " & ChrW(1080) & ChrW(1083) & ChrW(1080) & " " & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1072) & ChrW(1074) & ChrW(1100) & ChrW(1090) & ChrW(1077) & _
        " " & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1090) & ChrW(1099) & ChrW(1084) & ":] Is Null)"
    strSQL = strSQL & " ORDER BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072)
    strSQL = strSQL & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_3_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ChrW(1084)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080)
    strSQL = strSQL & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & _
        "] & ' ' & [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "] & ' ' & ["
    strSQL = strSQL & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        "] AS [" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "], Count(["
    strSQL = strSQL & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & _
        ChrW(1082) & ChrW(1072) & "]) AS [" & ChrW(1050) & ChrW(1086) & ChrW(1083) & "_" & ChrW(1086) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082)
    strSQL = strSQL & "], Round(Avg(1.00 * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094)
    strSQL = strSQL & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]), 2) AS [" & ChrW(1057) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & "], Min([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & _
        "_" & ChrW(1091) & ChrW(1089) & ChrW(1087)
    strSQL = strSQL & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & _
        "]) AS [" & ChrW(1052) & ChrW(1080) & ChrW(1085) & "_" & ChrW(1086) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "], Max([" & ChrW(1046) & ChrW(1091)
    strSQL = strSQL & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & _
        "]) AS [" & ChrW(1052) & ChrW(1072) & ChrW(1082) & ChrW(1089) & "_" & ChrW(1086) & ChrW(1094) & _
        ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]"
    strSQL = strSQL & ", IIf(Min([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "])=5, "
    strSQL = strSQL & "'" & ChrW(1054) & ChrW(1090) & ChrW(1083) & ChrW(1080) & ChrW(1095) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & "', IIf(Min([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & _
        "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094)
    strSQL = strSQL & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "])>=4, '" & ChrW(1061) & ChrW(1086) & ChrW(1088) & _
        ChrW(1086) & ChrW(1096) & ChrW(1080) & ChrW(1089) & ChrW(1090) & "', IIf(Min([" & ChrW(1046) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072)
    strSQL = strSQL & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "])>=3, '" & ChrW(1059) & ChrW(1089) & _
        ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1102) & ChrW(1097) & ChrW(1080) & ChrW(1081) & _
        "', '" & ChrW(1048) & ChrW(1084) & ChrW(1077) & ChrW(1077) & ChrW(1090) & " " & ChrW(1076) & _
        ChrW(1074)
    strSQL = strSQL & ChrW(1086) & ChrW(1081) & ChrW(1082) & ChrW(1080) & "'))) AS [" & ChrW(1057) & ChrW(1090) & ChrW(1072) & _
        ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & _
        ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        "] FROM ([" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089)
    strSQL = strSQL & ChrW(1089) & ChrW(1099) & "] INNER JOIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1080) & "] ON [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072)
    strSQL = strSQL & ChrW(1089) & ChrW(1089) & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "]) INNER JOIN [" & ChrW(1046) & _
        ChrW(1091)
    strSQL = strSQL & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "] ON [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "]"
    strSQL = strSQL & " = [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "] WHERE "
    strSQL = strSQL & "[" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "] Is Not Null GR"
    strSQL = strSQL & "OUP BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080)
    strSQL = strSQL & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & _
        "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1090) & ChrW(1095) & _
        ChrW(1077)
    strSQL = strSQL & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & "] ORDER BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & _
        ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "], Avg(1.00"
    strSQL = strSQL & " * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]) DESC;"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_4_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1072) & "], [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & _
        ChrW(1084)
    strSQL = strSQL & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & _
        ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1085) & ChrW(1072) & ChrW(1103) & "_" & ChrW(1086) & _
        ChrW(1073) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1090) & ChrW(1100) & "], Count([" & ChrW(1046) & _
        ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & _
        ChrW(1087) & ChrW(1077)
    strSQL = strSQL & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]) AS [" & _
        ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1086) & ChrW(1094) & _
        ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "], Sum(II"
    strSQL = strSQL & "f([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]=5, 1, 0)) AS"
    strSQL = strSQL & " [" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_5], Sum(IIf([" & _
        ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054)
    strSQL = strSQL & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]=4, 1, 0)) AS [" & ChrW(1054) & ChrW(1094) & _
        ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_4], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085)
    strSQL = strSQL & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & _
        ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]=3, 1, 0)) AS [" & ChrW(1054) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086)
    strSQL = strSQL & ChrW(1082) & "_3], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & _
        "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & _
        ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]="
    strSQL = strSQL & "2, 1, 0)) AS [" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_2], Round(Avg(1.00 * [" & _
        ChrW(1046) & ChrW(1091)
    strSQL = strSQL & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & _
        "]), 2) AS [" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_"
    strSQL = strSQL & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "], Round(100.0 * Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & _
        ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084)
    strSQL = strSQL & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]>=4, 1, 0)) / Count([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087)
    strSQL = strSQL & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & _
        "]), 1) AS [" & ChrW(1050) & ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & _
        ChrW(1086) & "_" & ChrW(1079) & ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_"
    strSQL = strSQL & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1094) & "] FROM (([" & ChrW(1055) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "] INNER JOIN [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1087)
    strSQL = strSQL & ChrW(1083) & ChrW(1072) & ChrW(1085) & "] ON [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & _
        ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & _
        ChrW(1081) & "_"
    strSQL = strSQL & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072) & "]) INNER JOIN [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080) & "] ON ["
    strSQL = strSQL & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & _
        ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1085) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & _
        ChrW(1080) & "] = [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1085)
    strSQL = strSQL & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080) & "]) INNER JOIN [" & _
        ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080) & "] ON"
    strSQL = strSQL & " [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072) & _
        "] = [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "]."
    strSQL = strSQL & "[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1072) & "] WHERE [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & _
        ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085)
    strSQL = strSQL & ChrW(1082) & ChrW(1072) & "] Is Not Null GROUP BY [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & _
        ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077)
    strSQL = strSQL & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072) & "], [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1099) & "].[" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1085) & ChrW(1072) & ChrW(1103) & "_" & ChrW(1086) & ChrW(1073) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1090) & ChrW(1100) & "] O"
    strSQL = strSQL & "RDER BY Avg(1.00 * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077)
    strSQL = strSQL & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]) DESC;"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_5_" & ChrW(1059) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084) & _
        "_" & ChrW(1080) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & ChrW(1084)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "], [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "]."
    strSQL = strSQL & "[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & _
        "] & ' ' & [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "] AS [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & "]"
    strSQL = strSQL & ", [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1072) & "], Count([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085)
    strSQL = strSQL & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & _
        ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]) AS [" & ChrW(1054) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "], Round"
    strSQL = strSQL & "(Avg(1.00 * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]), "
    strSQL = strSQL & "2) AS [" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "] FROM ((([" & ChrW(1050) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] INNER J"
    strSQL = strSQL & "OIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "] ON [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077)
    strSQL = strSQL & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "]) INNER JOIN [" & _
        ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072)
    strSQL = strSQL & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "] ON [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & "] = [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_"
    strSQL = strSQL & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "]) INNER JOIN [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082)
    strSQL = strSQL & ChrW(1080) & "] ON [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & _
        "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & _
        ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072) & "] = [" & _
        ChrW(1059) & ChrW(1088)
    strSQL = strSQL & ChrW(1086) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072) & "]) INNER JOIN ([" & ChrW(1055) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "] INNE"
    strSQL = strSQL & "R JOIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & _
        "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "] ON [" & ChrW(1055) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076)
    strSQL = strSQL & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & _
        ChrW(1085) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & "]) ON [" & ChrW(1059) & _
        ChrW(1088)
    strSQL = strSQL & ChrW(1086) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1085) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080) & _
        "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & _
        "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "].[" & ChrW(1050) & ChrW(1086) & _
        ChrW(1076) & "_" & ChrW(1085) & ChrW(1072) & ChrW(1075)
    strSQL = strSQL & ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080) & "] WHERE [" & ChrW(1046) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & _
        "] I"
    strSQL = strSQL & "s Not Null GROUP BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083)
    strSQL = strSQL & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & _
        ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & _
        ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & "],"
    strSQL = strSQL & " [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "], [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & _
        ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077)
    strSQL = strSQL & ChrW(1090) & ChrW(1072) & "] ORDER BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1099) & "].[" & ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & _
        ChrW(1077) & ChrW(1083) & ChrW(1100) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1080) & "]."
    strSQL = strSQL & "[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & _
        "], [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1072) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_6_" & ChrW(1055) & _
        ChrW(1077) & ChrW(1088) & ChrW(1077) & ChrW(1082) & ChrW(1088) & ChrW(1077) & ChrW(1089) & ChrW(1090) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1099) & "_" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1099)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "TRANSFORM Round(Avg(1.00 * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089)
    strSQL = strSQL & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & _
        ChrW(1072) & "]), 2) AS [" & ChrW(1057) & ChrW(1088) & ChrW(1041) & ChrW(1072) & ChrW(1083) & ChrW(1083) & _
        "] SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "]"
    strSQL = strSQL & ".[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & _
        ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & _
        "] AS [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & "], Round(Avg(1.00"
    strSQL = strSQL & " * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]), 2) AS [" & ChrW(1054) & ChrW(1073)
    strSQL = strSQL & ChrW(1097) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & _
        ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & _
        "] FROM ((([" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] INNER JOIN"
    strSQL = strSQL & " [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "] ON [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082)
    strSQL = strSQL & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "]) INNER JOIN [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & _
        ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086)
    strSQL = strSQL & ChrW(1089) & ChrW(1090) & ChrW(1080) & "] ON [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "] = [" & _
        ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087)
    strSQL = strSQL & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "]) INNER JOIN [" & ChrW(1059) & ChrW(1088) & _
        ChrW(1086) & ChrW(1082) & ChrW(1080) & "] "
    strSQL = strSQL & "ON [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072) & "] = [" & ChrW(1059) & _
        ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080)
    strSQL = strSQL & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1072) & "]) INNER JOIN ([" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1099) & "] INNER J"
    strSQL = strSQL & "OIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & _
        "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "] ON [" & ChrW(1055) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090)
    strSQL = strSQL & ChrW(1072) & "] = [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & _
        ChrW(1081) & "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1072) & "]) ON [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & _
        ChrW(1080)
    strSQL = strSQL & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1085) & ChrW(1072) & ChrW(1075) & _
        ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080) & "] = [" & ChrW(1059) & ChrW(1095) & _
        ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1087) & ChrW(1083) & _
        ChrW(1072) & ChrW(1085) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1085) & _
        ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1079)
    strSQL = strSQL & ChrW(1082) & ChrW(1080) & "] WHERE [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & _
        ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "] Is N"
    strSQL = strSQL & "ot Null GROUP BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089)
    strSQL = strSQL & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "] ORDER BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083)
    strSQL = strSQL & ChrW(1083) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "] PIVOT [" & ChrW(1055) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & _
        ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_7_" & ChrW(1058) & _
        ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "_" & _
        ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & _
        ChrW(1103) & "] & ' ' & [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "] & ' ' & [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        "] AS [" & ChrW(1060)
    strSQL = strSQL & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & "], Count([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & _
        ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & _
        ChrW(1086) & ChrW(1076)
    strSQL = strSQL & "_" & ChrW(1079) & ChrW(1072) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1080) & "]) AS [" & _
        ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1091) & ChrW(1088) & _
        ChrW(1086) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085) & ChrW(1072) & ChrW(1083) & "_"
    strSQL = strSQL & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & _
        ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & _
        ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]='" & ChrW(1055) & ChrW(1088) & _
        ChrW(1080) & ChrW(1089) & ChrW(1091) & ChrW(1090) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        ChrW(1074)
    strSQL = strSQL & ChrW(1072) & ChrW(1083) & "', 1, 0)) AS [" & ChrW(1055) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & _
        ChrW(1077) & ChrW(1085) & ChrW(1086) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089)
    strSQL = strSQL & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & _
        ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & _
        ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1103) & "]<>'" & ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1089) & _
        ChrW(1091) & ChrW(1090) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & ChrW(1074) & ChrW(1072)
    strSQL = strSQL & ChrW(1083) & "', 1, 0)) AS [" & ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & _
        ChrW(1074) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088)
    strSQL = strSQL & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & _
        ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & _
        ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1103) & "]='" & ChrW(1041) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & _
        ChrW(1100)
    strSQL = strSQL & " (" & ChrW(1041) & ")', 1, 0)) AS [" & ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & _
        ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1080) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072)
    strSQL = strSQL & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & _
        ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & _
        ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]='" & _
        ChrW(1059) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100)
    strSQL = strSQL & ChrW(1085) & ChrW(1072) & ChrW(1103) & " (" & ChrW(1059) & ")', 1, 0)) AS [" & ChrW(1059) & ChrW(1074) & _
        ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & _
        ChrW(1099) & ChrW(1093) & "], Sum(IIf(["
    strSQL = strSQL & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & _
        ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]='" & ChrW(1053) & ChrW(1077) & ChrW(1091) & _
        ChrW(1074)
    strSQL = strSQL & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & _
        ChrW(1072) & ChrW(1103) & " (" & ChrW(1053) & ")', 1, 0)) AS [" & ChrW(1053) & ChrW(1077) & ChrW(1091) & _
        ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & _
        ChrW(1085) & ChrW(1099) & ChrW(1093) & "], "
    strSQL = strSQL & "Round(100.0 * Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].["
    strSQL = strSQL & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & _
        ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & _
        "]='" & ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1089) & ChrW(1091) & ChrW(1090) & ChrW(1089) & _
        ChrW(1090) & ChrW(1074) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1083) & "', 1, 0)) / C"
    strSQL = strSQL & "ount([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1079) & ChrW(1072) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1080) & "]), 1) "
    strSQL = strSQL & "AS [" & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1090) & _
        "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "] FROM ([" & ChrW(1050) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] INNE"
    strSQL = strSQL & "R JOIN [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "] ON [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "] = ["
    strSQL = strSQL & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "]) INNER JOIN [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087)
    strSQL = strSQL & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & "] ON [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "] = [" & ChrW(1046) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085)
    strSQL = strSQL & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1072) & "] GROUP BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089)
    strSQL = strSQL & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & _
        ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072) & "], "
    strSQL = strSQL & "[" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & _
        ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & "],"
    strSQL = strSQL & " [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "].[" & ChrW(1048) & ChrW(1084) & ChrW(1103) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1090) & ChrW(1095) & _
        ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & "] ORDER "
    strSQL = strSQL & "BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & "].[" & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & _
        ChrW(1103) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    strName = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_8_" & ChrW(1057) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1072) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & _
        ChrW(1074)
    SafeDeleteObject acQuery, strName
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100) & _
        "], Round(Avg(1.0"
    strSQL = strSQL & "0 * [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]), 2) AS [" & ChrW(1057)
    strSQL = strSQL & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "], Round(100.0 * Sum(IIf([" & ChrW(1046)
    strSQL = strSQL & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & _
        ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & _
        ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & _
        ChrW(1072) & "]>=4, 1, 0)) / Cou"
    strSQL = strSQL & "nt([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "]), 1) AS [" & ChrW(1050) & ChrW(1072)
    strSQL = strSQL & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & "_" & ChrW(1079) & _
        ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1094) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & _
        ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & _
        ChrW(1077) & ChrW(1084)
    strSQL = strSQL & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & _
        ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & _
        ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]<>'" & ChrW(1055) & ChrW(1088) & _
        ChrW(1080) & ChrW(1089) & ChrW(1091) & ChrW(1090) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        ChrW(1074) & ChrW(1072) & ChrW(1083) & "', 1,"
    strSQL = strSQL & " 0)) AS [" & ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089)
    strSQL = strSQL & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & _
        ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & _
        ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1103) & "]='" & ChrW(1041) & ChrW(1086) & ChrW(1083) & ChrW(1077) & _
        ChrW(1079) & ChrW(1085) & ChrW(1100) & " (" & ChrW(1041) & ")',"
    strSQL = strSQL & " 1, 0)) AS [" & ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & _
        ChrW(1079) & ChrW(1085) & ChrW(1080) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077)
    strSQL = strSQL & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        "].[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & _
        ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1103) & "]='" & ChrW(1059) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " (" & ChrW(1059)
    strSQL = strSQL & ")', 1, 0)) AS [" & ChrW(1059) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1093) & "], Sum(IIf([" & ChrW(1046) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083)
    strSQL = strSQL & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & _
        ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]='" & ChrW(1053) & _
        ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083)
    strSQL = strSQL & ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " (" & ChrW(1053) & ")', 1, 0)) AS [" & ChrW(1053) & _
        ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1093) & "] FROM (["
    strSQL = strSQL & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "] INNER JOIN [" & ChrW(1059) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "] ON [" & ChrW(1050) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1050) & ChrW(1086) & _
        ChrW(1076)
    strSQL = strSQL & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "] = [" & _
        ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & "]) INNER JOIN"
    strSQL = strSQL & " [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "] ON [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "].[" & ChrW(1050) & ChrW(1086) & ChrW(1076) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1082) & ChrW(1072) & "] = [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "].[" & _
        ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1072) & "] GR"
    strSQL = strSQL & "OUP BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "].[" & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085)
    strSQL = strSQL & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "], [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & _
        "].[" & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100) & _
        "] ORDER BY [" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089)
    strSQL = strSQL & ChrW(1089) & ChrW(1099) & "].[" & ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "];"
    Set qdf = db.CreateQueryDef(strName, strSQL)
    db.QueryDefs.Refresh
End Sub

Public Sub BuildSubformStudents()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim ctl As Control
    target = ChrW(1055) & ChrW(1086) & ChrW(1076) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & _
        "_" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.RecordSource = ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080)
    frm.Caption = ChrW(1057) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1086) & ChrW(1082) & " " & ChrW(1091) & _
        ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & ChrW(1103) & " " & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072)
    frm.DefaultView = 1
    frm.ScrollBars = 2
    frm.Width = 10400
    frm.Section(acHeader).Height = 460
    frm.Section(acHeader).BackColor = RGB(30, 58, 138)
    frm.Section(acDetail).Height = 420
    frm.Section(acDetail).BackColor = RGB(255, 255, 255)
    frm.Section(acFooter).Height = 0
    AddFormLabel tmp, acHeader, ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103), 80, 100, 1850, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1048) & ChrW(1084) & ChrW(1103), 1980, 100, 1550, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086), 3580, 100, 1750, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & " " & ChrW(1088) & ChrW(1086) & ChrW(1078) & _
        ChrW(1076) & ".", 5380, 100, 1350, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1055) & ChrW(1086) & ChrW(1083), 6780, 100, 650, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & " " & _
        ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103), 7480, 100, 2750, 280, 9, True, RGB(255, 255, 255)
    AddFormField tmp, acDetail, "", ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103), 0, 0, 80, 1850, 50, 310
    AddFormField tmp, acDetail, "", ChrW(1048) & ChrW(1084) & ChrW(1103), 0, 0, 1980, 1550, 50, 310
    AddFormField tmp, acDetail, "", ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086), 0, 0, 3580, 1750, 50, 310
    Set ctl = AddFormField(tmp, acDetail, "", ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & "_" & ChrW(1088) & ChrW(1086) & ChrW(1078) & _
        ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103), 0, 0, 5380, 1350, 50, 310)
    ctl.Format = "Short Date"
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1055) & ChrW(1086) & ChrW(1083), 6780, 50, 650, 310)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1052) & ChrW(34) & ";" & ChrW(34) & ChrW(1046) & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 9
    AddFormField tmp, acDetail, "", ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & "_" & _
        ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103), 0, 0, 7480, 2750, 50, 310
    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildSubformGrades()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim ctl As Control
    Dim strSQL As String
    target = ChrW(1055) & ChrW(1086) & ChrW(1076) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & _
        "_" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1080) & "_" & _
        ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.RecordSource = ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080)
    frm.Caption = ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1080) & " " & ChrW(1080) & _
        " " & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1100) & " " & ChrW(1085) & ChrW(1072) & _
        " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1077)
    frm.DefaultView = 1
    frm.ScrollBars = 2
    frm.Width = 10400
    frm.Section(acHeader).Height = 460
    frm.Section(acHeader).BackColor = RGB(15, 118, 110)
    frm.Section(acDetail).Height = 420
    frm.Section(acDetail).BackColor = RGB(255, 255, 255)
    frm.Section(acFooter).Height = 0
    AddFormLabel tmp, acHeader, ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & " (" & ChrW(1050) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ")", 80, 100, 3100, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1055) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1100), 3240, 100, 2150, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072), 5450, 100, 900, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1042) & ChrW(1080) & ChrW(1076) & " " & ChrW(1088) & ChrW(1072) & ChrW(1073) & ChrW(1086) & _
        ChrW(1090) & ChrW(1099), 6410, 100, 2100, 280, 9, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1084) & ChrW(1077) & ChrW(1095) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077), 8570, 100, 1750, 280, 9, True, RGB(255, 255, 255)
    strSQL = ""
    strSQL = strSQL & "SELECT " & ChrW(1059) & "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ", " & ChrW(1059) & _
        "." & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ChrW(1083) & ChrW(1080) & ChrW(1103) & _
        " & ' ' & " & ChrW(1059) & "." & ChrW(1048) & ChrW(1084) & ChrW(1103)
    strSQL = strSQL & " & ' (' & " & ChrW(1050) & "." & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & _
        ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072) & " & ')' FROM " & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1099)
    strSQL = strSQL & " AS " & ChrW(1050) & " INNER JOIN " & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1080) & " AS " & ChrW(1059) & " ON " & ChrW(1050) & "." & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072)
    strSQL = strSQL & "=" & ChrW(1059) & "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & " ORDER BY " & ChrW(1050) & "." & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & ", " & ChrW(1059) & "." & ChrW(1060) & ChrW(1072) & ChrW(1084) & ChrW(1080) & _
        ChrW(1083) & ChrW(1080) & ChrW(1103)
    strSQL = strSQL & ";"
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1072), 80, 50, 3100, 310)
    ctl.RowSourceType = "Table/Query"
    ctl.RowSource = strSQL
    ctl.BoundColumn = 1
    ctl.ColumnCount = 2
    ctl.ColumnWidths = "0;3200"
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 9
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & ChrW(1087) & _
        ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103), 3240, 50, 2150, 310)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1089) & ChrW(1091) & ChrW(1090) & ChrW(1089) & _
        ChrW(1090) & ChrW(1074) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1083) & ChrW(34) & ";" & _
        ChrW(34) & ChrW(1041) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1100) & _
        " (" & ChrW(1041) & ")" & ChrW(34) & ";" & ChrW(34) & ChrW(1059) & ChrW(1074) & _
        ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & _
        ChrW(1072) & ChrW(1103) & " (" & ChrW(1059) & ")" & ChrW(34) & ";" & ChrW(34) & _
        ChrW(1053) & ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " (" & ChrW(1053) & _
        ")" & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 9
    Set ctl = AddFormField(tmp, acDetail, "", ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072), 0, 0, 5450, 900, 50, 310)
    ctl.TextAlign = 2
    ctl.FontBold = True
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1042) & ChrW(1080) & ChrW(1076) & "_" & ChrW(1086) & ChrW(1090) & ChrW(1074) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072), 6410, 50, 2100, 310)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1074) & ChrW(1077) & ChrW(1090) & " " & ChrW(1085) & _
        ChrW(1072) & " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1077) & ChrW(34) & _
        ";" & ChrW(34) & ChrW(1050) & ChrW(1086) & ChrW(1085) & ChrW(1090) & ChrW(1088) & ChrW(1086) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & ChrW(1072) & _
        ChrW(1073) & ChrW(1086) & ChrW(1090) & ChrW(1072) & ChrW(34) & ";" & ChrW(34) & ChrW(1057) & _
        ChrW(1072) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1086) & ChrW(1103) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & _
        ChrW(1072) & ChrW(1073) & ChrW(1086) & ChrW(1090) & ChrW(1072) & ChrW(34) & ";" & ChrW(34) & _
        ChrW(1044) & ChrW(1086) & ChrW(1084) & ChrW(1072) & ChrW(1096) & ChrW(1085) & ChrW(1103) & ChrW(1103) & _
        " " & ChrW(1088) & ChrW(1072) & ChrW(1073) & ChrW(1086) & ChrW(1090) & ChrW(1072) & ChrW(34) & _
        ";" & ChrW(34) & ChrW(1051) & ChrW(1072) & ChrW(1073) & ChrW(1086) & ChrW(1088) & ChrW(1072) & _
        ChrW(1090) & ChrW(1086) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & _
        ChrW(1072) & ChrW(1073) & ChrW(1086) & ChrW(1090) & ChrW(1072) & ChrW(34) & ";" & ChrW(34) & _
        ChrW(1041) & ChrW(1077) & ChrW(1079) & " " & ChrW(1086) & ChrW(1094) & ChrW(1077) & ChrW(1085) & _
        ChrW(1082) & ChrW(1080) & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 9
    AddFormField tmp, acDetail, "", ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1084) & ChrW(1077) & ChrW(1095) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077), 0, 0, 8570, 1750, 50, 310
    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildFormClasses()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim ctl As Control
    Dim ctlSub As Control
    Dim strSQL As String
    target = ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1050) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "_" & ChrW(1080) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.RecordSource = ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099)
    frm.Caption = ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & " " & ChrW(1080) & _
        " " & ChrW(1089) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1086) & ChrW(1095) & ChrW(1085) & _
        ChrW(1099) & ChrW(1081) & " " & ChrW(1089) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1072) & _
        ChrW(1074) & " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & _
        ChrW(1089) & ChrW(1103)
    frm.DefaultView = 0
    frm.Width = 10900
    frm.Section(acHeader).Height = 820
    frm.Section(acHeader).BackColor = RGB(26, 54, 93)
    frm.Section(acDetail).Height = 5200
    frm.Section(acDetail).BackColor = RGB(241, 245, 249)
    frm.Section(acFooter).Height = 0
    AddFormLabel tmp, acHeader, ChrW(1050) & ChrW(1051) & ChrW(1040) & ChrW(1057) & ChrW(1057) & ChrW(1067) & " " & ChrW(1048) & _
        " " & ChrW(1050) & ChrW(1054) & ChrW(1053) & ChrW(1058) & ChrW(1048) & ChrW(1053) & ChrW(1043) & _
        ChrW(1045) & ChrW(1053) & ChrW(1058) & " " & ChrW(1059) & ChrW(1063) & ChrW(1040) & ChrW(1065) & _
        ChrW(1048) & ChrW(1061) & ChrW(1057) & ChrW(1071), 240, 120, 7000, 360, 14, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1089) & ChrW(1084) & ChrW(1086) & ChrW(1090) & ChrW(1088) & _
        " " & ChrW(1080) & " " & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1072) & ChrW(1082) & _
        ChrW(1090) & ChrW(1080) & ChrW(1088) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & _
        ChrW(1077) & " " & ChrW(1082) & ChrW(1072) & ChrW(1088) & ChrW(1090) & ChrW(1086) & ChrW(1095) & _
        ChrW(1082) & ChrW(1080) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & " " & ChrW(1080) & " " & ChrW(1089) & ChrW(1087) & ChrW(1080) & ChrW(1089) & _
        ChrW(1082) & ChrW(1072) & " " & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074), 240, 470, 7000, 260, 9, False, RGB(203, 213, 225)
    AddFormButton tmp, acHeader, ChrW(1047) & ChrW(1072) & ChrW(1082) & ChrW(1088) & ChrW(1099) & ChrW(1090) & ChrW(1100), "=NavCloseForm(" & ChrW(34) & target & ChrW(34) & ")", 9100, 190, 1550, 440, RGB(37, 99, 235), RGB(255, 255, 255)
    AddFormBox tmp, acDetail, 200, 160, 10500, 1480, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormField tmp, acDetail, ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ":", ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072), 400, 1300, 1750, 1100, 320, 330
    AddFormField tmp, acDetail, ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & ":", ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100), 3100, 1250, 4400, 900, 320, 330
    AddFormField tmp, acDetail, ChrW(1050) & ChrW(1072) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1077) & ChrW(1090) & ":", ChrW(1050) & ChrW(1072) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1077) & ChrW(1090) & "_" & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072), 5600, 1050, 6700, 1100, 320, 330
    AddFormField tmp, acDetail, ChrW(1059) & ChrW(1095) & ". " & ChrW(1075) & ChrW(1086) & ChrW(1076) & ":", ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & _
        ChrW(1075) & ChrW(1086) & ChrW(1076), 8050, 1000, 9100, 1350, 320, 330
    AddFormLabel tmp, acDetail, ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100) & ":", 400, 860, 1300, 330, 10, True, RGB(30, 41, 59)
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & ChrW(1083) & ChrW(1100), 1750, 830, 3550, 330)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1054) & ChrW(1073) & ChrW(1097) & ChrW(1077) & ChrW(1086) & ChrW(1073) & ChrW(1088) & _
        ChrW(1072) & ChrW(1079) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1090) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1081) & ChrW(34) & ";" & ChrW(34) & ChrW(1060) & _
        ChrW(1080) & ChrW(1079) & ChrW(1080) & ChrW(1082) & ChrW(1086) & "-" & ChrW(1084) & ChrW(1072) & _
        ChrW(1090) & ChrW(1077) & ChrW(1084) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1095) & ChrW(1077) & _
        ChrW(1089) & ChrW(1082) & ChrW(1080) & ChrW(1081) & ChrW(34) & ";" & ChrW(34) & ChrW(1048) & _
        ChrW(1085) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & ChrW(1094) & ChrW(1080) & _
        ChrW(1086) & ChrW(1085) & ChrW(1085) & ChrW(1086) & "-" & ChrW(1090) & ChrW(1077) & ChrW(1093) & _
        ChrW(1085) & ChrW(1086) & ChrW(1083) & ChrW(1086) & ChrW(1075) & ChrW(1080) & ChrW(1095) & ChrW(1077) & _
        ChrW(1089) & ChrW(1082) & ChrW(1080) & ChrW(1081) & ChrW(34) & ";" & ChrW(34) & ChrW(1043) & _
        ChrW(1091) & ChrW(1084) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1090) & ChrW(1072) & ChrW(1088) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & ChrW(34) & ";" & ChrW(34) & ChrW(1045) & ChrW(1089) & _
        ChrW(1090) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1077) & ChrW(1085) & ChrW(1085) & _
        ChrW(1086) & "-" & ChrW(1085) & ChrW(1072) & ChrW(1091) & ChrW(1095) & ChrW(1085) & ChrW(1099) & _
        ChrW(1081) & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    AddFormLabel tmp, acDetail, ChrW(1050) & ChrW(1083) & ". " & ChrW(1088) & ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ":", 5550, 860, 1850, 330, 10, True, RGB(30, 41, 59)
    strSQL = ""
    strSQL = strSQL & "SELECT [" & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "], [" & ChrW(1060) & ChrW(1048) & ChrW(1054) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "] FROM [" & ChrW(1059) & ChrW(1095) & ChrW(1080)
    strSQL = strSQL & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "] ORDER BY [" & ChrW(1060) & ChrW(1048) & ChrW(1054) & _
        "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        "];"
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & "_" & ChrW(1088) & _
        ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103), 7450, 830, 3000, 330)
    ctl.RowSourceType = "Table/Query"
    ctl.RowSource = strSQL
    ctl.BoundColumn = 1
    ctl.ColumnCount = 2
    ctl.ColumnWidths = "0;3200"
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    AddFormLabel tmp, acDetail, ChrW(1057) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1086) & ChrW(1082) & " " & ChrW(1091) & _
        ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & ChrW(1103) & " " & _
        ChrW(1074) & ChrW(1099) & ChrW(1073) & ChrW(1088) & ChrW(1072) & ChrW(1085) & ChrW(1085) & ChrW(1086) & _
        ChrW(1075) & ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & ":", 220, 1760, 5500, 300, 10, True, RGB(26, 54, 93)
    Set ctlSub = CreateFormControl(tmp, acSubform, acDetail, "", "", 200, 2100, 10500, 2900)
    ctlSub.SourceObject = ChrW(1055) & ChrW(1086) & ChrW(1076) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & _
        "_" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072)
    ctlSub.LinkChildFields = ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072)
    ctlSub.LinkMasterFields = ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1072)
    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildFormJournal()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim ctl As Control
    Dim ctlSub As Control
    Dim strSQL As String
    target = ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1042) & ChrW(1077) & _
        ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1078) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(1072)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.RecordSource = ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080)
    frm.Caption = ChrW(1069) & ChrW(1083) & ChrW(1077) & ChrW(1082) & ChrW(1090) & ChrW(1088) & ChrW(1086) & ChrW(1085) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085) & ChrW(1072) & ChrW(1083)
    frm.DefaultView = 0
    frm.Width = 10900
    frm.Section(acHeader).Height = 820
    frm.Section(acHeader).BackColor = RGB(15, 118, 110)
    frm.Section(acDetail).Height = 5650
    frm.Section(acDetail).BackColor = RGB(241, 245, 249)
    frm.Section(acFooter).Height = 0
    AddFormLabel tmp, acHeader, ChrW(1069) & ChrW(1051) & ChrW(1045) & ChrW(1050) & ChrW(1058) & ChrW(1056) & ChrW(1054) & ChrW(1053) & _
        ChrW(1053) & ChrW(1067) & ChrW(1049) & " " & ChrW(1046) & ChrW(1059) & ChrW(1056) & ChrW(1053) & _
        ChrW(1040) & ChrW(1051) & " " & ChrW(1059) & ChrW(1057) & ChrW(1055) & ChrW(1045) & ChrW(1042) & _
        ChrW(1040) & ChrW(1045) & ChrW(1052) & ChrW(1054) & ChrW(1057) & ChrW(1058) & ChrW(1048) & " " & _
        ChrW(1048) & " " & ChrW(1055) & ChrW(1054) & ChrW(1057) & ChrW(1045) & ChrW(1065) & ChrW(1040) & _
        ChrW(1045) & ChrW(1052) & ChrW(1054) & ChrW(1057) & ChrW(1058) & ChrW(1048), 240, 120, 8200, 360, 14, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1042) & ChrW(1099) & ChrW(1073) & ChrW(1077) & ChrW(1088) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        " " & ChrW(1080) & ChrW(1083) & ChrW(1080) & " " & ChrW(1089) & ChrW(1086) & ChrW(1079) & _
        ChrW(1076) & ChrW(1072) & ChrW(1081) & ChrW(1090) & ChrW(1077) & " " & ChrW(1091) & ChrW(1088) & _
        ChrW(1086) & ChrW(1082) & " " & ChrW(1080) & " " & ChrW(1074) & ChrW(1099) & ChrW(1089) & _
        ChrW(1090) & ChrW(1072) & ChrW(1074) & ChrW(1100) & ChrW(1090) & ChrW(1077) & " " & ChrW(1086) & _
        ChrW(1090) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1082) & ChrW(1080) & " / " & ChrW(1087) & _
        ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1080) & " " & _
        ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ChrW(1084) & _
        " " & ChrW(1085) & ChrW(1080) & ChrW(1078) & ChrW(1077), 240, 470, 8200, 260, 9, False, RGB(204, 251, 241)
    AddFormButton tmp, acHeader, ChrW(1047) & ChrW(1072) & ChrW(1082) & ChrW(1088) & ChrW(1099) & ChrW(1090) & ChrW(1100), "=NavCloseForm(" & ChrW(34) & target & ChrW(34) & ")", 9100, 190, 1550, 440, RGB(17, 94, 89), RGB(255, 255, 255)
    AddFormBox tmp, acDetail, 200, 150, 10500, 1900, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & " " & ChrW(1080) & " " & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ":", 380, 300, 1750, 330, 10, True, RGB(30, 41, 59)
    strSQL = ""
    strSQL = strSQL & "SELECT " & ChrW(1059) & "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1085) & _
        ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080) & ", " & _
        ChrW(1050) & "." & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & " & ' "
    strSQL = strSQL & ChrW(8212) & " ' & " & ChrW(1055) & "." & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & _
        ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & " & ' (' & " & ChrW(1058) & "." & _
        ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090)
    strSQL = strSQL & ChrW(1077) & ChrW(1083) & ChrW(1103) & " & ')' FROM ((" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1087) & ChrW(1083) & ChrW(1072) & ChrW(1085) & _
        " AS " & ChrW(1059) & " INNER JOIN"
    strSQL = strSQL & " " & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & " AS " & _
        ChrW(1050) & " ON " & ChrW(1059) & "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & "=" & ChrW(1050) & _
        "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072) & ") IN"
    strSQL = strSQL & "NER JOIN " & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1099) & " AS " & ChrW(1055) & " ON " & ChrW(1059) & "." & ChrW(1050) & ChrW(1086) & _
        ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072) & "=" & ChrW(1055) & "." & ChrW(1050) & ChrW(1086)
    strSQL = strSQL & ChrW(1076) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072) & ") INNER JOIN " & ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1103) & " AS " & ChrW(1058) & " ON " & ChrW(1059) & "." & ChrW(1050) & _
        ChrW(1086) & ChrW(1076) & "_"
    strSQL = strSQL & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & "=" & _
        ChrW(1058) & "." & ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & _
        ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & " ORDER BY " & ChrW(1050) & "." & _
        ChrW(1055) & ChrW(1072) & ChrW(1088) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & ", " & ChrW(1055)
    strSQL = strSQL & "." & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & _
        ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072) & ";"
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1085) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1091) & ChrW(1079) & ChrW(1082) & ChrW(1080), 2150, 270, 5200, 340)
    ctl.RowSourceType = "Table/Query"
    ctl.RowSource = strSQL
    ctl.BoundColumn = 1
    ctl.ColumnCount = 2
    ctl.ColumnWidths = "0;5200"
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    Set ctl = AddFormField(tmp, acDetail, ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & ":", ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1072), 7550, 650, 8220, 1250, 270, 340)
    ctl.Format = "Short Date"
    AddFormField tmp, acDetail, ChrW(8470) & ":", ChrW(1053) & ChrW(1086) & ChrW(1084) & ChrW(1077) & ChrW(1088) & "_" & ChrW(1091) & ChrW(1088) & _
        ChrW(1086) & ChrW(1082) & ChrW(1072), 9600, 350, 9980, 520, 270, 340
    AddFormField tmp, acDetail, ChrW(1058) & ChrW(1077) & ChrW(1084) & ChrW(1072) & " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1072) & ":", ChrW(1058) & ChrW(1077) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1072), 380, 1750, 2150, 8350, 730, 340
    AddFormLabel tmp, acDetail, ChrW(1058) & ChrW(1080) & ChrW(1087) & " " & ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & _
        ChrW(1090) & ChrW(1080) & ChrW(1103) & ":", 380, 1220, 1750, 330, 10, True, RGB(30, 41, 59)
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1058) & ChrW(1080) & ChrW(1087) & "_" & ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & _
        ChrW(1090) & ChrW(1080) & ChrW(1103), 2150, 1190, 3100, 340)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1050) & ChrW(1086) & ChrW(1084) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1080) & _
        ChrW(1088) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1085) & ChrW(1099) & ChrW(1081) & _
        " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(34) & ";" & ChrW(34) & _
        ChrW(1050) & ChrW(1086) & ChrW(1085) & ChrW(1090) & ChrW(1088) & ChrW(1086) & ChrW(1083) & ChrW(1100) & _
        ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & ChrW(1072) & ChrW(1073) & ChrW(1086) & _
        ChrW(1090) & ChrW(1072) & ChrW(34) & ";" & ChrW(34) & ChrW(1057) & ChrW(1072) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1086) & ChrW(1103) & ChrW(1090) & ChrW(1077) & ChrW(1083) & _
        ChrW(1100) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & ChrW(1072) & ChrW(1073) & _
        ChrW(1086) & ChrW(1090) & ChrW(1072) & ChrW(34) & ";" & ChrW(34) & ChrW(1051) & ChrW(1072) & _
        ChrW(1073) & ChrW(1086) & ChrW(1088) & ChrW(1072) & ChrW(1090) & ChrW(1086) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1103) & " " & ChrW(1088) & ChrW(1072) & ChrW(1073) & ChrW(1086) & ChrW(1090) & _
        ChrW(1072) & ChrW(34) & ";" & ChrW(34) & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & _
        "-" & ChrW(1087) & ChrW(1088) & ChrW(1072) & ChrW(1082) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1091) & ChrW(1084) & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    AddFormField tmp, acDetail, ChrW(1044) & ChrW(1086) & ChrW(1084) & ". " & ChrW(1079) & ChrW(1072) & ChrW(1076) & ChrW(1072) & _
        ChrW(1085) & ChrW(1080) & ChrW(1077) & ":", ChrW(1044) & ChrW(1086) & ChrW(1084) & ChrW(1072) & ChrW(1096) & ChrW(1085) & ChrW(1077) & ChrW(1077) & _
        "_" & ChrW(1079) & ChrW(1072) & ChrW(1076) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077), 5450, 1450, 6950, 3550, 1190, 340
    AddFormLabel tmp, acDetail, ChrW(1042) & ChrW(1077) & ChrW(1076) & ChrW(1086) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1100) & " " & ChrW(1086) & ChrW(1090) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1086) & _
        ChrW(1082) & " " & ChrW(1080) & " " & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & _
        ChrW(1097) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        " " & ChrW(1085) & ChrW(1072) & " " & ChrW(1090) & ChrW(1077) & ChrW(1082) & ChrW(1091) & _
        ChrW(1097) & ChrW(1077) & ChrW(1084) & " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & _
        ChrW(1077) & ":", 220, 2170, 6500, 300, 10, True, RGB(15, 118, 110)
    Set ctlSub = CreateFormControl(tmp, acSubform, acDetail, "", "", 200, 2500, 10500, 2980)
    ctlSub.SourceObject = ChrW(1055) & ChrW(1086) & ChrW(1076) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & _
        "_" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1080) & "_" & _
        ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1072)
    ctlSub.LinkChildFields = ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & _
        ChrW(1072)
    ctlSub.LinkMasterFields = ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & _
        ChrW(1072)
    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildFormTeachers()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim ctl As Control
    target = ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1059) & ChrW(1095) & _
        ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.RecordSource = ChrW(1059) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103)
    frm.Caption = ChrW(1057) & ChrW(1087) & ChrW(1088) & ChrW(1072) & ChrW(1074) & ChrW(1086) & ChrW(1095) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & " " & ChrW(1087) & ChrW(1077) & ChrW(1076) & ChrW(1072) & ChrW(1075) & _
        ChrW(1086) & ChrW(1075) & ChrW(1080) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1082) & ChrW(1086) & _
        ChrW(1075) & ChrW(1086) & " " & ChrW(1089) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1072) & _
        ChrW(1074) & ChrW(1072)
    frm.DefaultView = 0
    frm.Width = 9200
    frm.Section(acHeader).Height = 800
    frm.Section(acHeader).BackColor = RGB(67, 56, 202)
    frm.Section(acDetail).Height = 3300
    frm.Section(acDetail).BackColor = RGB(241, 245, 249)
    frm.Section(acFooter).Height = 0
    AddFormLabel tmp, acHeader, ChrW(1055) & ChrW(1045) & ChrW(1044) & ChrW(1040) & ChrW(1043) & ChrW(1054) & ChrW(1043) & ChrW(1048) & _
        ChrW(1063) & ChrW(1045) & ChrW(1057) & ChrW(1050) & ChrW(1048) & ChrW(1049) & " " & ChrW(1057) & _
        ChrW(1054) & ChrW(1057) & ChrW(1058) & ChrW(1040) & ChrW(1042) & " " & ChrW(1064) & ChrW(1050) & _
        ChrW(1054) & ChrW(1051) & ChrW(1067), 240, 130, 6500, 360, 14, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1050) & ChrW(1072) & ChrW(1088) & ChrW(1090) & ChrW(1086) & ChrW(1095) & ChrW(1082) & ChrW(1072) & _
        " " & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & _
        ": " & ChrW(1082) & ChrW(1074) & ChrW(1072) & ChrW(1083) & ChrW(1080) & ChrW(1092) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & ChrW(1094) & ChrW(1080) & ChrW(1103) & ", " & ChrW(1089) & ChrW(1090) & _
        ChrW(1072) & ChrW(1078) & " " & ChrW(1080) & " " & ChrW(1082) & ChrW(1086) & ChrW(1085) & _
        ChrW(1090) & ChrW(1072) & ChrW(1082) & ChrW(1090) & ChrW(1085) & ChrW(1099) & ChrW(1077) & " " & _
        ChrW(1076) & ChrW(1072) & ChrW(1085) & ChrW(1085) & ChrW(1099) & ChrW(1077), 240, 470, 6500, 250, 9, False, RGB(224, 231, 255)
    AddFormButton tmp, acHeader, ChrW(1047) & ChrW(1072) & ChrW(1082) & ChrW(1088) & ChrW(1099) & ChrW(1090) & ChrW(1100), "=NavCloseForm(" & ChrW(34) & target & ChrW(34) & ")", 7400, 180, 1550, 440, RGB(79, 70, 229), RGB(255, 255, 255)
    AddFormBox tmp, acDetail, 240, 220, 8700, 2850, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormField tmp, acDetail, ChrW(1050) & ChrW(1086) & ChrW(1076) & " " & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103) & ":", ChrW(1050) & ChrW(1086) & ChrW(1076) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103), 500, 2200, 2800, 1400, 420, 340
    AddFormField tmp, acDetail, ChrW(1060) & ChrW(1048) & ChrW(1054) & " " & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103) & ":", ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & _
        ChrW(1077) & ChrW(1083) & ChrW(1103), 500, 2200, 2800, 5800, 880, 340
    AddFormField tmp, acDetail, ChrW(1057) & ChrW(1087) & ChrW(1077) & ChrW(1094) & ChrW(1080) & ChrW(1072) & ChrW(1083) & ChrW(1080) & _
        ChrW(1079) & ChrW(1072) & ChrW(1094) & ChrW(1080) & ChrW(1103) & ":", ChrW(1057) & ChrW(1087) & ChrW(1077) & ChrW(1094) & ChrW(1080) & ChrW(1072) & ChrW(1083) & ChrW(1080) & _
        ChrW(1079) & ChrW(1072) & ChrW(1094) & ChrW(1080) & ChrW(1103), 500, 2200, 2800, 5800, 1340, 340
    AddFormLabel tmp, acDetail, ChrW(1050) & ChrW(1072) & ChrW(1090) & ChrW(1077) & ChrW(1075) & ChrW(1086) & ChrW(1088) & ChrW(1080) & _
        ChrW(1103) & ":", 500, 1830, 2200, 340, 10, True, RGB(30, 41, 59)
    Set ctl = CreateFormControl(tmp, acComboBox, acDetail, "", ChrW(1050) & ChrW(1072) & ChrW(1090) & ChrW(1077) & ChrW(1075) & ChrW(1086) & ChrW(1088) & ChrW(1080) & _
        ChrW(1103), 2800, 1800, 3200, 340)
    ctl.RowSourceType = "Value List"
    ctl.RowSource = ChrW(34) & ChrW(1042) & ChrW(1099) & ChrW(1089) & ChrW(1096) & ChrW(1072) & ChrW(1103) & ChrW(34) & _
        ";" & ChrW(34) & ChrW(1055) & ChrW(1077) & ChrW(1088) & ChrW(1074) & ChrW(1072) & ChrW(1103) & _
        ChrW(34) & ";" & ChrW(34) & ChrW(1057) & ChrW(1086) & ChrW(1086) & ChrW(1090) & ChrW(1074) & _
        ChrW(1077) & ChrW(1090) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1080) & ChrW(1077) & " " & _
        ChrW(1076) & ChrW(1086) & ChrW(1083) & ChrW(1078) & ChrW(1085) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080) & ChrW(34) & ";" & ChrW(34) & ChrW(1052) & ChrW(1086) & ChrW(1083) & ChrW(1086) & _
        ChrW(1076) & ChrW(1086) & ChrW(1081) & " " & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1094) & _
        ChrW(1080) & ChrW(1072) & ChrW(1083) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(34)
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 10
    AddFormField tmp, acDetail, ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1078) & " (" & ChrW(1083) & ChrW(1077) & ChrW(1090) & _
        "):", ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1078) & "_" & ChrW(1083) & ChrW(1077) & ChrW(1090), 6250, 1250, 7550, 1050, 1800, 340
    AddFormField tmp, acDetail, ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & ":", ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085), 500, 2200, 2800, 3200, 2280, 340
    AddFormField tmp, acDetail, ChrW(1050) & ChrW(1072) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1077) & ChrW(1090) & ":", ChrW(1050) & ChrW(1072) & ChrW(1073) & ChrW(1080) & ChrW(1085) & ChrW(1077) & ChrW(1090), 6250, 1250, 7550, 1050, 2280, 340
    SaveAndRenameForm tmp, target
End Sub


Public Sub BuildFormAnalytics()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    Dim db As Object
    Dim rs As Object
    Dim i As Long
    Dim barH As Long
    Dim maxH As Long
    Dim xPos As Long
    Dim barW As Long
    Dim avgVal As Double
    Dim qualVal As Double
    Dim absTotal As Long
    Dim absSick As Long
    Dim totalStudents As Long
    Dim totalLessons As Long
    Dim schoolAvg As Double
    Dim totalAbsences As Long
    Dim subjName As String
    Dim clsName As String
    Dim barColor As Long
    Dim strSQL As String

    target = ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1099)
    SafeDeleteObject acForm, target
    Set db = CurrentDb

    Set rs = db.OpenRecordset("SELECT Count(*) AS C FROM [" & ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & "]")
    If Not rs.EOF Then totalStudents = CLng(rs!C)
    rs.Close

    Set rs = db.OpenRecordset("SELECT Count(*) AS C FROM [" & ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1080) & "]")
    If Not rs.EOF Then totalLessons = CLng(rs!C)
    rs.Close

    strSQL = ""
    strSQL = strSQL & "SELECT Round(Avg(1.00*[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1082) & ChrW(1072) & "]),2) AS A FROM "
    strSQL = strSQL & "[" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "] WHERE [" & ChrW(1054) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1082) & ChrW(1072) & "] Is Not N"
    strSQL = strSQL & "ull;"
    Set rs = db.OpenRecordset(strSQL)
    If Not rs.EOF Then schoolAvg = CDbl(rs!A)
    rs.Close

    strSQL = ""
    strSQL = strSQL & "SELECT Count(*) AS C FROM [" & ChrW(1046) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090)
    strSQL = strSQL & ChrW(1080) & "] WHERE [" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & _
        "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1103) & "] <> '" & ChrW(1055) & ChrW(1088) & ChrW(1080) & ChrW(1089) & ChrW(1091) & _
        ChrW(1090) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1083)
    strSQL = strSQL & "';"
    Set rs = db.OpenRecordset(strSQL)
    If Not rs.EOF Then totalAbsences = CLng(rs!C)
    rs.Close

    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp

    frm.Caption = ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & " " & ChrW(1080) & " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & _
        ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1099) & " " & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080) & " " & ChrW(1080) & " " & ChrW(1087) & ChrW(1086) & _
        ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & _
        ChrW(1090) & ChrW(1080)
    frm.ScrollBars = 0
    frm.RecordSelectors = False
    frm.NavigationButtons = False
    frm.DividingLines = False
    frm.Width = 12200

    frm.Section(acHeader).Height = 840
    frm.Section(acHeader).BackColor = RGB(26, 54, 93)
    frm.Section(acDetail).Height = 6850
    frm.Section(acDetail).BackColor = RGB(241, 245, 249)
    frm.Section(acFooter).Height = 0

    AddFormLabel tmp, acHeader, ChrW(1040) & ChrW(1053) & ChrW(1040) & ChrW(1051) & ChrW(1048) & ChrW(1058) & ChrW(1048) & ChrW(1063) & _
        ChrW(1045) & ChrW(1057) & ChrW(1050) & ChrW(1040) & ChrW(1071) & " " & ChrW(1055) & ChrW(1040) & _
        ChrW(1053) & ChrW(1045) & ChrW(1051) & ChrW(1068) & " " & ChrW(1048) & " " & ChrW(1044) & _
        ChrW(1048) & ChrW(1040) & ChrW(1043) & ChrW(1056) & ChrW(1040) & ChrW(1052) & ChrW(1052) & ChrW(1067) & _
        " " & ChrW(1064) & ChrW(1050) & ChrW(1054) & ChrW(1051) & ChrW(1068) & ChrW(1053) & ChrW(1054) & _
        ChrW(1043) & ChrW(1054) & " " & ChrW(1046) & ChrW(1059) & ChrW(1056) & ChrW(1053) & ChrW(1040) & _
        ChrW(1051) & ChrW(1040), 240, 120, 8200, 360, 14, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1057) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1085) & ChrW(1099) & ChrW(1077) & " " & _
        ChrW(1087) & ChrW(1086) & ChrW(1082) & ChrW(1072) & ChrW(1079) & ChrW(1072) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1080) & " " & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & " " & _
        ChrW(1087) & ChrW(1086) & " " & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084) & " " & ChrW(1080) & " " & ChrW(1089) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1072) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1082) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & ChrW(1084), 240, 480, 8200, 260, 9, False, RGB(203, 213, 225)
    AddFormButton tmp, acHeader, ChrW(1054) & ChrW(1073) & ChrW(1085) & ChrW(1086) & ChrW(1074) & ChrW(1080) & ChrW(1090) & ChrW(1100) & _
        " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & _
        ChrW(1084) & ChrW(1099), "=NavRebuildAnalytics()", 8650, 190, 1850, 440, RGB(13, 148, 136), RGB(255, 255, 255)
    AddFormButton tmp, acHeader, ChrW(1047) & ChrW(1072) & ChrW(1082) & ChrW(1088) & ChrW(1099) & ChrW(1090) & ChrW(1100), "=NavCloseForm(" & ChrW(34) & target & ChrW(34) & ")", 10600, 190, 1350, 440, RGB(37, 99, 235), RGB(255, 255, 255)

    AddFormBox tmp, acDetail, 200, 160, 2800, 920, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1059) & ChrW(1063) & ChrW(1040) & ChrW(1065) & ChrW(1048) & ChrW(1061) & ChrW(1057) & ChrW(1071) & _
        " " & ChrW(1042) & " " & ChrW(1064) & ChrW(1050) & ChrW(1054) & ChrW(1051) & ChrW(1045), 360, 240, 2400, 250, 8, True, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, CStr(totalStudents), 360, 500, 2400, 460, 18, True, RGB(26, 54, 93)

    AddFormBox tmp, acDetail, 3200, 160, 2800, 920, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1055) & ChrW(1056) & ChrW(1054) & ChrW(1042) & ChrW(1045) & ChrW(1044) & ChrW(1045) & ChrW(1053) & _
        ChrW(1054) & " " & ChrW(1059) & ChrW(1056) & ChrW(1054) & ChrW(1050) & ChrW(1054) & ChrW(1042), 3360, 240, 2400, 250, 8, True, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, CStr(totalLessons), 3360, 500, 2400, 460, 18, True, RGB(13, 148, 136)

    AddFormBox tmp, acDetail, 6200, 160, 2800, 920, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1057) & ChrW(1056) & ChrW(1045) & ChrW(1044) & ChrW(1053) & ChrW(1048) & ChrW(1049) & " " & _
        ChrW(1041) & ChrW(1040) & ChrW(1051) & ChrW(1051) & " " & ChrW(1064) & ChrW(1050) & ChrW(1054) & _
        ChrW(1051) & ChrW(1067), 6360, 240, 2400, 250, 8, True, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, Format(schoolAvg, "0.00"), 6360, 500, 2400, 460, 18, True, RGB(37, 99, 235)

    AddFormBox tmp, acDetail, 9200, 160, 2800, 920, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1042) & ChrW(1057) & ChrW(1045) & ChrW(1043) & ChrW(1054) & " " & ChrW(1055) & ChrW(1056) & _
        ChrW(1054) & ChrW(1055) & ChrW(1059) & ChrW(1057) & ChrW(1050) & ChrW(1054) & ChrW(1042) & " " & _
        ChrW(1047) & ChrW(1040) & ChrW(1053) & ChrW(1071) & ChrW(1058) & ChrW(1048) & ChrW(1049), 9360, 240, 2500, 250, 8, True, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, CStr(totalAbsences), 9360, 500, 2400, 460, 18, True, RGB(217, 119, 6)

    AddFormBox tmp, acDetail, 200, 1260, 6250, 5350, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1044) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084) & _
        ChrW(1072) & " 1. " & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & _
        ChrW(1081) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & " " & ChrW(1087) & _
        ChrW(1086) & " " & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & _
        ChrW(1084) & " " & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072) & ChrW(1084), 400, 1400, 5800, 340, 11, True, RGB(26, 54, 93)
    AddFormLabel tmp, acDetail, ChrW(1064) & ChrW(1082) & ChrW(1072) & ChrW(1083) & ChrW(1072) & " " & ChrW(1086) & ChrW(1090) & _
        " 0 " & ChrW(1076) & ChrW(1086) & " 5 " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & _
        ChrW(1086) & ChrW(1074) & " (" & ChrW(1094) & ChrW(1074) & ChrW(1077) & ChrW(1090) & " " & _
        ChrW(1089) & ChrW(1090) & ChrW(1086) & ChrW(1083) & ChrW(1073) & ChrW(1094) & ChrW(1072) & " " & _
        ChrW(1086) & ChrW(1090) & ChrW(1088) & ChrW(1072) & ChrW(1078) & ChrW(1072) & ChrW(1077) & ChrW(1090) & _
        " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1074) & ChrW(1077) & ChrW(1085) & ChrW(1100) & _
        " " & ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1077) & ChrW(1075) & _
        ChrW(1086) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1072) & ")", 400, 1740, 5800, 260, 8, False, RGB(100, 116, 139)

    AddFormBox tmp, acDetail, 720, 2400, 5500, 3000, RGB(248, 250, 252), RGB(226, 232, 240)
    AddFormLabel tmp, acDetail, "5.0", 330, 2300, 360, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, "4.0", 330, 2900, 360, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, "3.0", 330, 3500, 360, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, "2.0", 330, 4100, 360, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, "0.0", 330, 5280, 360, 240, 8, False, RGB(100, 116, 139)

    Set rs = db.OpenRecordset(ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_4_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084))
    i = 0
    barW = 470
    Do While Not rs.EOF And i < 8
        avgVal = CDbl(rs.Fields(ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083)).Value)
        qualVal = CDbl(rs.Fields(ChrW(1050) & ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        "_" & ChrW(1079) & ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1094)).Value)
        subjName = CStr(rs.Fields(ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072)).Value)
        If Len(subjName) > 8 Then subjName = Left(subjName, 7) & "."
        barH = CLng(avgVal * 600)
        If barH < 120 Then barH = 120
        xPos = 840 + i * 665
        If avgVal >= 4.5 Then
            barColor = RGB(16, 185, 129)
        ElseIf avgVal >= 4# Then
            barColor = RGB(37, 99, 235)
        Else
            barColor = RGB(245, 158, 11)
        End If
        AddFormBox tmp, acDetail, xPos, 5400 - barH, barW, barH, barColor, barColor
        AddFormLabel tmp, acDetail, Format(avgVal, "0.00"), xPos - 30, 5400 - barH - 270, 560, 250, 8, True, RGB(15, 23, 42)
        AddFormLabel tmp, acDetail, subjName, xPos - 70, 5460, 640, 300, 8, True, RGB(51, 65, 85)
        AddFormLabel tmp, acDetail, CStr(Round(qualVal, 0)) & "%", xPos - 10, 5740, 540, 240, 7, False, RGB(100, 116, 139)
        i = i + 1
        rs.MoveNext
    Loop
    rs.Close
    AddFormLabel tmp, acDetail, ChrW(1055) & ChrW(1086) & ChrW(1076) & " " & ChrW(1087) & ChrW(1086) & ChrW(1076) & ChrW(1087) & _
        ChrW(1080) & ChrW(1089) & ChrW(1103) & ChrW(1084) & ChrW(1080) & " " & ChrW(1087) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1086) & ChrW(1074) & " " & _
        ChrW(1091) & ChrW(1082) & ChrW(1072) & ChrW(1079) & ChrW(1072) & ChrW(1085) & " % " & ChrW(1082) & _
        ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1072) & " " & _
        ChrW(1079) & ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & " (" & ChrW(1076) & _
        ChrW(1086) & ChrW(1083) & ChrW(1103) & " " & ChrW(171) & "4" & ChrW(187) & " " & _
        ChrW(1080) & " " & ChrW(171) & "5" & ChrW(187) & ")", 400, 6160, 5800, 260, 8, False, RGB(100, 116, 139)

    AddFormBox tmp, acDetail, 6650, 1260, 5350, 5350, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, ChrW(1044) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084) & _
        ChrW(1072) & " 2. " & ChrW(1058) & ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & _
        " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & _
        ChrW(1086) & ChrW(1074) & " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & ChrW(1084), 6850, 1400, 4950, 340, 11, True, RGB(26, 54, 93)
    AddFormLabel tmp, acDetail, ChrW(1054) & ChrW(1088) & ChrW(1072) & ChrW(1085) & ChrW(1078) & ChrW(1077) & ChrW(1074) & ChrW(1099) & _
        ChrW(1081) & " " & ChrW(8212) & " " & ChrW(1074) & ChrW(1089) & ChrW(1077) & ChrW(1075) & _
        ChrW(1086) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & ", " & ChrW(1089) & ChrW(1080) & ChrW(1085) & ChrW(1080) & _
        ChrW(1081) & " " & ChrW(8212) & " " & ChrW(1074) & " " & ChrW(1090) & "." & _
        ChrW(1095) & ". " & ChrW(1087) & ChrW(1086) & " " & ChrW(1073) & ChrW(1086) & ChrW(1083) & _
        ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1080) & " (" & ChrW(1041) & ")", 6850, 1740, 4950, 260, 8, False, RGB(100, 116, 139)

    AddFormBox tmp, acDetail, 7150, 2400, 4600, 3000, RGB(248, 250, 252), RGB(226, 232, 240)
    maxH = 6
    Set rs = db.OpenRecordset(ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_8_" & ChrW(1057) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1072) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & _
        ChrW(1074))
    Do While Not rs.EOF
        If CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value) > maxH Then
            maxH = CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value)
        End If
        rs.MoveNext
    Loop
    rs.MoveFirst

    AddFormLabel tmp, acDetail, CStr(maxH), 6800, 2320, 320, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, CStr(CLng(maxH / 2)), 6800, 3820, 320, 240, 8, False, RGB(100, 116, 139)
    AddFormLabel tmp, acDetail, "0", 6800, 5280, 320, 240, 8, False, RGB(100, 116, 139)

    i = 0
    Do While Not rs.EOF And i < 6
        clsName = CStr(rs.Fields(ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072)).Value)
        absTotal = CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value)
        absSick = CLng(rs.Fields(ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & _
        ChrW(1085) & ChrW(1080)).Value)
        xPos = 7320 + i * 740
        barH = CLng((CDbl(absTotal) / CDbl(maxH)) * 2700)
        If barH < 80 And absTotal > 0 Then barH = 80
        If barH > 0 Then
            AddFormBox tmp, acDetail, xPos, 5400 - barH, 260, barH, RGB(234, 88, 12), RGB(234, 88, 12)
        End If
        AddFormLabel tmp, acDetail, CStr(absTotal), xPos + 20, 5400 - barH - 270, 300, 240, 8, True, RGB(194, 65, 12)

        barH = CLng((CDbl(absSick) / CDbl(maxH)) * 2700)
        If barH < 80 And absSick > 0 Then barH = 80
        If barH > 0 Then
            AddFormBox tmp, acDetail, xPos + 280, 5400 - barH, 240, barH, RGB(59, 130, 246), RGB(59, 130, 246)
        End If
        AddFormLabel tmp, acDetail, CStr(absSick), xPos + 300, 5400 - barH - 270, 300, 240, 8, False, RGB(29, 78, 216)
        AddFormLabel tmp, acDetail, clsName, xPos + 80, 5480, 500, 280, 9, True, RGB(30, 41, 59)
        i = i + 1
        rs.MoveNext
    Loop
    rs.Close

    AddFormButton tmp, acDetail, ChrW(1054) & ChrW(1090) & ChrW(1082) & ChrW(1088) & ChrW(1099) & ChrW(1090) & ChrW(1100) & " " & _
        ChrW(1087) & ChrW(1077) & ChrW(1095) & ChrW(1072) & ChrW(1090) & ChrW(1085) & ChrW(1099) & ChrW(1081) & _
        " " & ChrW(1086) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & " " & ChrW(1089) & _
        " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & _
        ChrW(1084) & ChrW(1072) & ChrW(1084) & ChrW(1080), "=NavOpenReport(" & ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_4_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1087) & ChrW(1086) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & _
        ChrW(1084) & ChrW(34) & ")", 7150, 6000, 4600, 430, RGB(26, 54, 93), RGB(255, 255, 255)
    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildFormMain()
    Dim frm As Form
    Dim tmp As String
    Dim target As String
    target = ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1043) & ChrW(1083) & _
        ChrW(1072) & ChrW(1074) & ChrW(1085) & ChrW(1072) & ChrW(1103)
    SafeDeleteObject acForm, target
    Set frm = CreateForm
    tmp = frm.Name
    EnsureFormHeaderFooter frm, tmp
    frm.Caption = ChrW(1040) & ChrW(1048) & ChrW(1057) & " " & ChrW(171) & ChrW(1064) & ChrW(1082) & ChrW(1086) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(187) & " " & ChrW(8212) & " " & _
        ChrW(1043) & ChrW(1083) & ChrW(1072) & ChrW(1074) & ChrW(1085) & ChrW(1086) & ChrW(1077) & " " & _
        ChrW(1084) & ChrW(1077) & ChrW(1085) & ChrW(1102)
    frm.ScrollBars = 0
    frm.RecordSelectors = False
    frm.NavigationButtons = False
    frm.DividingLines = False
    frm.Width = 11600
    frm.Section(acHeader).Height = 1050
    frm.Section(acHeader).BackColor = RGB(26, 54, 93)
    frm.Section(acDetail).Height = 5950
    frm.Section(acDetail).BackColor = RGB(241, 245, 249)
    frm.Section(acFooter).Height = 0

    AddFormLabel tmp, acHeader, ChrW(1040) & ChrW(1048) & ChrW(1057) & " " & ChrW(171) & ChrW(1064) & ChrW(1050) & ChrW(1054) & _
        ChrW(1051) & ChrW(1068) & ChrW(1053) & ChrW(1067) & ChrW(1049) & " " & ChrW(1046) & ChrW(1059) & _
        ChrW(1056) & ChrW(1053) & ChrW(1040) & ChrW(1051) & ChrW(187), 300, 160, 8500, 420, 16, True, RGB(255, 255, 255)
    AddFormLabel tmp, acHeader, ChrW(1040) & ChrW(1074) & ChrW(1090) & ChrW(1086) & ChrW(1084) & ChrW(1072) & ChrW(1090) & ChrW(1080) & _
        ChrW(1079) & ChrW(1080) & ChrW(1088) & ChrW(1086) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1085) & _
        ChrW(1072) & ChrW(1103) & " " & ChrW(1089) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1077) & _
        ChrW(1084) & ChrW(1072) & " " & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1090) & ChrW(1072) & _
        " " & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & " " & ChrW(1080) & " " & _
        ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & _
        ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & ChrW(1103) & " " & ChrW(1096) & ChrW(1082) & _
        ChrW(1086) & ChrW(1083) & ChrW(1099), 300, 620, 9500, 280, 10, False, RGB(203, 213, 225)

    AddFormBox tmp, acDetail, 240, 240, 3550, 5450, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, "1. " & ChrW(1042) & ChrW(1045) & ChrW(1044) & ChrW(1045) & ChrW(1053) & ChrW(1048) & ChrW(1045) & _
        " " & ChrW(1046) & ChrW(1059) & ChrW(1056) & ChrW(1053) & ChrW(1040) & ChrW(1051) & ChrW(1040) & _
        " " & ChrW(1048) & " " & ChrW(1060) & ChrW(1054) & ChrW(1056) & ChrW(1052) & ChrW(1067), 420, 420, 3200, 340, 11, True, RGB(26, 54, 93)
    AddFormLabel tmp, acDetail, ChrW(1042) & ChrW(1074) & ChrW(1086) & ChrW(1076) & " " & ChrW(1091) & ChrW(1088) & ChrW(1086) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & ", " & ChrW(1086) & ChrW(1094) & ChrW(1077) & ChrW(1085) & _
        ChrW(1086) & ChrW(1082) & ", " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & _
        ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & " " & ChrW(1080) & " " & ChrW(1089) & _
        ChrW(1087) & ChrW(1088) & ChrW(1072) & ChrW(1074) & ChrW(1086) & ChrW(1095) & ChrW(1085) & ChrW(1080) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & ":", 420, 780, 3200, 300, 8, False, RGB(100, 116, 139)
    AddFormButton tmp, acDetail, ChrW(1042) & ChrW(1077) & ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1077) & " " & _
        ChrW(1078) & ChrW(1091) & ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(1072) & " " & _
        ChrW(1091) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1086) & ChrW(1074), "=NavOpenForm(" & ChrW(34) & ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1042) & ChrW(1077) & _
        ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1077) & "_" & ChrW(1078) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(1072) & ChrW(34) & ")", 420, 1200, 3180, 580, RGB(13, 148, 136), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & " " & ChrW(1080) & _
        " " & ChrW(1089) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & " " & _
        ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1086) & ChrW(1074), "=NavOpenForm(" & ChrW(34) & ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1050) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1099) & "_" & ChrW(1080) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1080) & ChrW(34) & ")", 420, 1940, 3180, 580, RGB(37, 99, 235), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1057) & ChrW(1087) & ChrW(1088) & ChrW(1072) & ChrW(1074) & ChrW(1086) & ChrW(1095) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & " " & ChrW(1091) & ChrW(1095) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1077) & ChrW(1081), "=NavOpenForm(" & ChrW(34) & ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1059) & ChrW(1095) & _
        ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1103) & ChrW(34) & ")", 420, 2680, 3180, 580, RGB(67, 56, 202), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1055) & ChrW(1072) & ChrW(1085) & ChrW(1077) & ChrW(1083) & ChrW(1100) & " " & ChrW(1089) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1080) & " " & ChrW(1080) & " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & _
        ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084), "=NavOpenForm(" & ChrW(34) & ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1099) & ChrW(34) & ")", 420, 3420, 3180, 640, RGB(217, 119, 6), RGB(255, 255, 255)

    AddFormBox tmp, acDetail, 4020, 240, 3550, 5450, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, "2. " & ChrW(1047) & ChrW(1040) & ChrW(1055) & ChrW(1056) & ChrW(1054) & ChrW(1057) & ChrW(1067) & _
        " " & ChrW(1048) & " " & ChrW(1042) & ChrW(1067) & ChrW(1041) & ChrW(1054) & ChrW(1056) & _
        ChrW(1050) & ChrW(1048), 4200, 420, 3200, 340, 11, True, RGB(26, 54, 93)
    AddFormLabel tmp, acDetail, ChrW(1057) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & ", " & ChrW(1089) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1077) & " " & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1099) & ", " & ChrW(1090) & ChrW(1072) & ChrW(1073) & _
        ChrW(1077) & ChrW(1083) & ChrW(1100) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & _
        ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & ":", 4200, 780, 3200, 300, 8, False, RGB(100, 116, 139)
    AddFormButton tmp, acDetail, ChrW(1057) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & " " & ChrW(1074) & _
        ChrW(1089) & ChrW(1077) & ChrW(1093) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1086) & ChrW(1074), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_1_" & ChrW(1057) & _
        ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074) & ChrW(34) & ")", 4200, 1200, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1055) & ChrW(1086) & ChrW(1080) & ChrW(1089) & ChrW(1082) & " " & ChrW(1091) & ChrW(1095) & _
        ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1086) & ChrW(1074) & " " & ChrW(1087) & _
        ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1091), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_2_" & ChrW(1055) & _
        ChrW(1086) & ChrW(1080) & ChrW(1089) & ChrW(1082) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072) & ChrW(34) & ")", 4200, 1820, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & " " & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & " " & ChrW(1087) & ChrW(1086) & " " & _
        ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ChrW(1084), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_3_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ChrW(1084) & ChrW(34) & ")", 4200, 2440, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & " " & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & " " & ChrW(1087) & ChrW(1086) & " " & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & _
        ChrW(1084), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_4_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084) & ChrW(34) & ")", 4200, 3060, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1055) & ChrW(1077) & ChrW(1088) & ChrW(1077) & ChrW(1082) & ChrW(1088) & ChrW(1077) & ChrW(1089) & _
        ChrW(1090) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & ChrW(1084) & ChrW(1072) & ChrW(1090) & _
        ChrW(1088) & ChrW(1080) & ChrW(1094) & ChrW(1072) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & ChrW(1086) & ChrW(1074), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_6_" & ChrW(1055) & _
        ChrW(1077) & ChrW(1088) & ChrW(1077) & ChrW(1082) & ChrW(1088) & ChrW(1077) & ChrW(1089) & ChrW(1090) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & "_" & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & _
        ChrW(1089) & ChrW(1099) & "_" & ChrW(1055) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & _
        ChrW(1077) & ChrW(1090) & ChrW(1099) & ChrW(34) & ")", 4200, 3680, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1058) & ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & " " & ChrW(1087) & _
        ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        " " & ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_7_" & ChrW(1058) & _
        ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "_" & _
        ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081) & ChrW(34) & ")", 4200, 4300, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1057) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & _
        ChrW(1089) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1086) & ChrW(1074), "=NavOpenQuery(" & ChrW(34) & ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_8_" & ChrW(1057) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1072) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & _
        ChrW(1074) & ChrW(34) & ")", 4200, 4920, 3180, 500, RGB(51, 65, 85), RGB(255, 255, 255)

    AddFormBox tmp, acDetail, 7800, 240, 3550, 5450, RGB(255, 255, 255), RGB(203, 213, 225)
    AddFormLabel tmp, acDetail, "3. " & ChrW(1055) & ChrW(1045) & ChrW(1063) & ChrW(1040) & ChrW(1058) & ChrW(1053) & ChrW(1067) & _
        ChrW(1045) & " " & ChrW(1054) & ChrW(1058) & ChrW(1063) & ChrW(1045) & ChrW(1058) & ChrW(1067), 7980, 420, 3200, 340, 11, True, RGB(26, 54, 93)
    AddFormLabel tmp, acDetail, ChrW(1043) & ChrW(1086) & ChrW(1090) & ChrW(1086) & ChrW(1074) & ChrW(1099) & ChrW(1077) & " " & _
        ChrW(1076) & ChrW(1086) & ChrW(1082) & ChrW(1091) & ChrW(1084) & ChrW(1077) & ChrW(1085) & ChrW(1090) & _
        ChrW(1099) & " " & ChrW(1089) & " " & ChrW(1075) & ChrW(1088) & ChrW(1091) & ChrW(1087) & _
        ChrW(1087) & ChrW(1080) & ChrW(1088) & ChrW(1086) & ChrW(1074) & ChrW(1082) & ChrW(1086) & ChrW(1081) & _
        " " & ChrW(1080) & " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1072) & ChrW(1084) & ChrW(1080) & ":", 7980, 780, 3200, 300, 8, False, RGB(100, 116, 139)
    AddFormButton tmp, acDetail, ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & " 1. " & ChrW(1057) & ChrW(1087) & _
        ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074), "=NavOpenReport(" & ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_1_" & ChrW(1057) & ChrW(1087) & _
        ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074) & ChrW(34) & ")", 7980, 1200, 3180, 620, RGB(30, 64, 175), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & " 2. " & ChrW(1057) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1077) & " " & ChrW(1073) & ChrW(1072) & _
        ChrW(1083) & ChrW(1083) & ChrW(1099), "=NavOpenReport(" & ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_2_" & ChrW(1042) & ChrW(1077) & _
        ChrW(1076) & ChrW(1086) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1100) & "_" & _
        ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1093) & "_" & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1086) & ChrW(1074) & ChrW(34) & ")", 7980, 1980, 3180, 620, RGB(30, 64, 175), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & " 3. " & ChrW(1058) & ChrW(1072) & _
        ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & _
        ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & " + " & ChrW(1076) & _
        ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ".", "=NavOpenReport(" & ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_3_" & ChrW(1058) & ChrW(1072) & _
        ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1086) & _
        ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "_" & ChrW(1079) & _
        ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081) & ChrW(34) & ")", 7980, 2760, 3180, 620, RGB(180, 83, 9), RGB(255, 255, 255)
    AddFormButton tmp, acDetail, ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & " 4. " & ChrW(1055) & ChrW(1088) & _
        ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1099) & " " & ChrW(1080) & _
        " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & _
        ChrW(1084) & ChrW(1072), "=NavOpenReport(" & ChrW(34) & ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_4_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1087) & ChrW(1086) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & _
        ChrW(1084) & ChrW(34) & ")", 7980, 3540, 3180, 620, RGB(15, 118, 110), RGB(255, 255, 255)

    SaveAndRenameForm tmp, target
End Sub

Public Sub BuildReportClassLists()
    Dim rpt As Report
    Dim tmp As String
    Dim target As String
    Dim grp As Variant
    Dim ctl As Control
    Dim strExpr As String
    target = ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_1_" & ChrW(1057) & ChrW(1087) & _
        ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074)
    SafeDeleteObject acReport, target
    Set rpt = CreateReport
    tmp = rpt.Name
    EnsureReportHeaderFooter rpt, tmp
    rpt.RecordSource = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_1_" & ChrW(1057) & _
        ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & "_" & ChrW(1082) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074)
    rpt.Caption = ChrW(1057) & ChrW(1087) & ChrW(1080) & ChrW(1089) & ChrW(1082) & ChrW(1080) & " " & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1093) & " " & ChrW(1082) & _
        ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & ChrW(1074) & " " & ChrW(1096) & _
        ChrW(1082) & ChrW(1086) & ChrW(1083) & ChrW(1099)
    rpt.Width = 9800
    grp = CreateGroupLevel(tmp, ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072), True, True)
    grp = CreateGroupLevel(tmp, ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1072), False, False)
    rpt.Section(acHeader).Height = 820
    rpt.Section(acHeader).BackColor = RGB(26, 54, 93)
    rpt.Section(acPageHeader).Height = 460
    rpt.Section(acPageHeader).BackColor = RGB(226, 232, 240)
    rpt.Section(acGroupLevel1Header).Height = 480
    rpt.Section(acGroupLevel1Header).BackColor = RGB(239, 246, 255)
    rpt.Section(acDetail).Height = 360
    rpt.Section(acGroupLevel1Footer).Height = 400
    rpt.Section(acFooter).Height = 500
    rpt.Section(acPageFooter).Height = 380

    AddReportLabel tmp, acHeader, ChrW(1055) & ChrW(1054) & ChrW(1060) & ChrW(1040) & ChrW(1052) & ChrW(1048) & ChrW(1051) & ChrW(1068) & _
        ChrW(1053) & ChrW(1067) & ChrW(1045) & " " & ChrW(1057) & ChrW(1055) & ChrW(1048) & ChrW(1057) & _
        ChrW(1050) & ChrW(1048) & " " & ChrW(1059) & ChrW(1063) & ChrW(1040) & ChrW(1065) & ChrW(1048) & _
        ChrW(1061) & ChrW(1057) & ChrW(1071) & " " & ChrW(1055) & ChrW(1054) & " " & ChrW(1050) & _
        ChrW(1051) & ChrW(1040) & ChrW(1057) & ChrW(1057) & ChrW(1040) & ChrW(1052) & " " & ChrW(1064) & _
        ChrW(1050) & ChrW(1054) & ChrW(1051) & ChrW(1067), 200, 120, 9200, 360, 14, True, RGB(255, 255, 255)
    AddReportLabel tmp, acHeader, ChrW(1057) & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1080) & ChrW(1088) & ChrW(1086) & _
        ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1086) & " " & ChrW(1074) & " " & ChrW(1040) & _
        ChrW(1048) & ChrW(1057) & " " & ChrW(171) & ChrW(1064) & ChrW(1082) & ChrW(1086) & ChrW(1083) & _
        ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & ChrW(1088) & _
        ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(187) & " (2026/2027 " & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1075) & ChrW(1086) & ChrW(1076) & _
        ")", 200, 480, 9200, 250, 9, False, RGB(203, 213, 225)
    AddReportLabel tmp, acPageHeader, ChrW(1060) & ChrW(1048) & ChrW(1054) & " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & _
        ChrW(1077) & ChrW(1075) & ChrW(1086) & ChrW(1089) & ChrW(1103), 180, 90, 3800, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & " " & ChrW(1088) & ChrW(1086) & ChrW(1078) & _
        ChrW(1076) & ".", 4050, 90, 1400, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1055) & ChrW(1086) & ChrW(1083), 5500, 90, 600, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & " " & _
        ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1077) & _
        ChrW(1081), 6150, 90, 3500, 280, 9, True, RGB(15, 23, 42)

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & " " & _
        ChrW(34) & " & [" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "] & " & ChrW(34) & "  |  " & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & _
        ChrW(1080) & ChrW(1083) & ChrW(1100)
    strExpr = strExpr & ": " & ChrW(34) & " & [" & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1092) & ChrW(1080) & _
        ChrW(1083) & ChrW(1100) & "] & " & ChrW(34) & "  |  " & ChrW(1050) & ChrW(1083) & ". " & _
        ChrW(1088) & ChrW(1091) & ChrW(1082) & ".: " & ChrW(34) & " & [" & ChrW(1050) & ChrW(1083) & _
        ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1085)
    strExpr = strExpr & ChrW(1099) & ChrW(1081) & "_" & ChrW(1088) & ChrW(1091) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "]"
    AddReportText tmp, acGroupLevel1Header, strExpr, 180, 90, 9400, 300, 10, True, RGB(30, 64, 175), 1
    AddReportText tmp, acDetail, "[" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "]", 180, 40, 3800, 280, 9, False, RGB(15, 23, 42), 1
    Set ctl = AddReportText(tmp, acDetail, "[" & ChrW(1044) & ChrW(1072) & ChrW(1090) & ChrW(1072) & "_" & ChrW(1088) & ChrW(1086) & _
        ChrW(1078) & ChrW(1076) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & "]", 4050, 40, 1400, 280, 9, False, RGB(15, 23, 42), 2)
    ctl.Format = "Short Date"
    AddReportText tmp, acDetail, "[" & ChrW(1055) & ChrW(1086) & ChrW(1083) & "]", 5500, 40, 600, 280, 9, False, RGB(15, 23, 42), 2
    AddReportText tmp, acDetail, "[" & ChrW(1058) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1092) & ChrW(1086) & ChrW(1085) & _
        "_" & ChrW(1088) & ChrW(1086) & ChrW(1076) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & _
        ChrW(1103) & "]", 6150, 40, 3500, 280, 9, False, RGB(15, 23, 42), 1

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1048) & ChrW(1090) & ChrW(1086) & ChrW(1075) & ChrW(1086) & " " & _
        ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & ChrW(1103) & _
        " " & ChrW(1074) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1077) & ": " & ChrW(34) & " & Count(*)"
    AddReportText tmp, acGroupLevel1Footer, strExpr, 180, 60, 5000, 280, 9, True, RGB(51, 65, 85), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1042) & ChrW(1057) & ChrW(1045) & ChrW(1043) & ChrW(1054) & " " & _
        ChrW(1059) & ChrW(1063) & ChrW(1040) & ChrW(1065) & ChrW(1048) & ChrW(1061) & ChrW(1057) & ChrW(1071) & _
        " " & ChrW(1055) & ChrW(1054) & " " & ChrW(1064) & ChrW(1050) & ChrW(1054) & ChrW(1051) & _
        ChrW(1045) & ": " & ChrW(34) & " & Count(*)"
    AddReportText tmp, acFooter, strExpr, 180, 100, 6500, 320, 11, True, RGB(26, 54, 93), 1
    AddReportText tmp, acPageFooter, "=Now()", 180, 60, 3500, 260, 8, False, RGB(100, 116, 139), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1057) & ChrW(1090) & ChrW(1088) & ". " & ChrW(34) & " & [Page] & " & _
        ChrW(34) & " " & ChrW(1080) & ChrW(1079) & " " & ChrW(34) & " & [Pages]"
    AddReportText tmp, acPageFooter, strExpr, 7200, 60, 2400, 260, 8, False, RGB(100, 116, 139), 3
    SaveAndRenameReport tmp, target
End Sub

Public Sub BuildReportStudentAverages()
    Dim rpt As Report
    Dim tmp As String
    Dim target As String
    Dim grp As Variant
    Dim strExpr As String
    target = ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_2_" & ChrW(1042) & ChrW(1077) & _
        ChrW(1076) & ChrW(1086) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1100) & "_" & _
        ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1093) & "_" & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1086) & ChrW(1074)
    SafeDeleteObject acReport, target
    Set rpt = CreateReport
    tmp = rpt.Name
    EnsureReportHeaderFooter rpt, tmp
    rpt.RecordSource = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_3_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & ChrW(1084)
    rpt.Caption = ChrW(1057) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1085) & ChrW(1072) & ChrW(1103) & " " & _
        ChrW(1074) & ChrW(1077) & ChrW(1076) & ChrW(1086) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1100) & " " & ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & _
        ChrW(1093) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1086) & ChrW(1074) & _
        " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & _
        ChrW(1103)
    rpt.Width = 9800
    grp = CreateGroupLevel(tmp, ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072), True, True)
    grp = CreateGroupLevel(tmp, ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083), False, False)
    rpt.GroupLevel(1).SortOrder = True
    rpt.Section(acHeader).Height = 820
    rpt.Section(acHeader).BackColor = RGB(15, 118, 110)
    rpt.Section(acPageHeader).Height = 460
    rpt.Section(acPageHeader).BackColor = RGB(226, 232, 240)
    rpt.Section(acGroupLevel1Header).Height = 440
    rpt.Section(acGroupLevel1Header).BackColor = RGB(240, 253, 250)
    rpt.Section(acDetail).Height = 360
    rpt.Section(acGroupLevel1Footer).Height = 420
    rpt.Section(acFooter).Height = 520
    rpt.Section(acPageFooter).Height = 380

    AddReportLabel tmp, acHeader, ChrW(1042) & ChrW(1045) & ChrW(1044) & ChrW(1054) & ChrW(1052) & ChrW(1054) & ChrW(1057) & ChrW(1058) & _
        ChrW(1068) & " " & ChrW(1057) & ChrW(1056) & ChrW(1045) & ChrW(1044) & ChrW(1053) & ChrW(1048) & _
        ChrW(1061) & " " & ChrW(1041) & ChrW(1040) & ChrW(1051) & ChrW(1051) & ChrW(1054) & ChrW(1042) & _
        " " & ChrW(1048) & " " & ChrW(1059) & ChrW(1057) & ChrW(1055) & ChrW(1045) & ChrW(1042) & _
        ChrW(1040) & ChrW(1045) & ChrW(1052) & ChrW(1054) & ChrW(1057) & ChrW(1058) & ChrW(1048) & " " & _
        ChrW(1059) & ChrW(1063) & ChrW(1040) & ChrW(1065) & ChrW(1048) & ChrW(1061) & ChrW(1057) & ChrW(1071), 200, 120, 9200, 360, 14, True, RGB(255, 255, 255)
    AddReportLabel tmp, acHeader, ChrW(1056) & ChrW(1077) & ChrW(1081) & ChrW(1090) & ChrW(1080) & ChrW(1085) & ChrW(1075) & " " & _
        ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & ChrW(1080) & ChrW(1093) & ChrW(1089) & ChrW(1103) & _
        " " & ChrW(1074) & ChrW(1085) & ChrW(1091) & ChrW(1090) & ChrW(1088) & ChrW(1080) & " " & _
        ChrW(1082) & ChrW(1072) & ChrW(1078) & ChrW(1076) & ChrW(1086) & ChrW(1075) & ChrW(1086) & " " & _
        ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072) & " " & ChrW(1087) & _
        ChrW(1086) & " " & ChrW(1089) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1077) & _
        ChrW(1084) & ChrW(1091) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & ChrW(1091) & _
        " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1074) & ChrW(1089) & ChrW(1077) & ChrW(1084) & _
        " " & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072) & ChrW(1084), 200, 480, 9200, 250, 9, False, RGB(204, 251, 241)
    AddReportLabel tmp, acPageHeader, ChrW(1060) & ChrW(1048) & ChrW(1054) & " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & _
        ChrW(1077) & ChrW(1075) & ChrW(1086) & ChrW(1089) & ChrW(1103), 180, 90, 3600, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082), 3850, 90, 900, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1057) & ChrW(1088) & ". " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083), 4800, 90, 1050, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1064) & ChrW(1082) & ChrW(1072) & ChrW(1083) & ChrW(1072), 5900, 90, 1650, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & " " & ChrW(1091) & _
        ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & _
        ChrW(1089) & ChrW(1090) & ChrW(1080), 7600, 90, 2050, 280, 9, True, RGB(15, 23, 42)

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ": " & _
        ChrW(34) & " & [" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "]"
    AddReportText tmp, acGroupLevel1Header, strExpr, 180, 70, 5000, 280, 10, True, RGB(15, 118, 110), 1
    AddReportText tmp, acDetail, "[" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "]", 180, 40, 3600, 280, 9, False, RGB(15, 23, 42), 1
    AddReportText tmp, acDetail, "[" & ChrW(1050) & ChrW(1086) & ChrW(1083) & "_" & ChrW(1086) & ChrW(1094) & ChrW(1077) & _
        ChrW(1085) & ChrW(1086) & ChrW(1082) & "]", 3850, 40, 900, 280, 9, False, RGB(15, 23, 42), 2
    strExpr = ""
    strExpr = strExpr & "=Format([" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "]," & ChrW(34) & "0.00" & _
        ChrW(34) & ")"
    AddReportText tmp, acDetail, strExpr, 4800, 40, 1050, 280, 9, True, RGB(30, 64, 175), 2
    strExpr = ""
    strExpr = strExpr & "=String(Int([" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "]*3)," & ChrW(34) & ChrW(9608) & _
        ChrW(34) & ")"
    AddReportText tmp, acDetail, strExpr, 5900, 40, 1650, 280, 9, False, RGB(13, 148, 136), 1
    AddReportText tmp, acDetail, "[" & ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1091) & ChrW(1089) & "_" & _
        ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & _
        ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "]", 7600, 40, 2050, 280, 9, False, RGB(15, 23, 42), 1

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & _
        ChrW(1081) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & " " & ChrW(1087) & _
        ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1091) & _
        ": " & ChrW(34) & " & Format(Avg([" & ChrW(1057) & ChrW(1088) & ChrW(1077)
    strExpr = strExpr & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & "])," & ChrW(34) & "0.00" & ChrW(34) & ")"
    AddReportText tmp, acGroupLevel1Footer, strExpr, 180, 70, 6000, 280, 9, True, RGB(15, 118, 110), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1054) & ChrW(1041) & ChrW(1065) & ChrW(1048) & ChrW(1049) & " " & _
        ChrW(1057) & ChrW(1056) & ChrW(1045) & ChrW(1044) & ChrW(1053) & ChrW(1048) & ChrW(1049) & " " & _
        ChrW(1041) & ChrW(1040) & ChrW(1051) & ChrW(1051) & " " & ChrW(1055) & ChrW(1054) & " " & _
        ChrW(1064) & ChrW(1050) & ChrW(1054) & ChrW(1051) & ChrW(1045) & ": " & ChrW(34) & " & Format(Avg"
    strExpr = strExpr & "([" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "])," & ChrW(34) & "0.00" & _
        ChrW(34) & ")"
    AddReportText tmp, acFooter, strExpr, 180, 110, 7000, 320, 11, True, RGB(15, 118, 110), 1
    AddReportText tmp, acPageFooter, "=Now()", 180, 60, 3500, 260, 8, False, RGB(100, 116, 139), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1057) & ChrW(1090) & ChrW(1088) & ". " & ChrW(34) & " & [Page] & " & _
        ChrW(34) & " " & ChrW(1080) & ChrW(1079) & " " & ChrW(34) & " & [Pages]"
    AddReportText tmp, acPageFooter, strExpr, 7200, 60, 2400, 260, 8, False, RGB(100, 116, 139), 3
    SaveAndRenameReport tmp, target
End Sub

Public Sub BuildReportAttendance()
    Dim rpt As Report
    Dim tmp As String
    Dim target As String
    Dim grp As Variant
    Dim db As Object
    Dim rs As Object
    Dim i As Long
    Dim maxH As Long
    Dim absTotal As Long
    Dim absSick As Long
    Dim barH As Long
    Dim xPos As Long
    Dim clsName As String
    Dim strExpr As String

    target = ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_3_" & ChrW(1058) & ChrW(1072) & _
        ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1086) & _
        ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "_" & ChrW(1079) & _
        ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081)
    SafeDeleteObject acReport, target
    Set db = CurrentDb
    Set rpt = CreateReport
    tmp = rpt.Name
    EnsureReportHeaderFooter rpt, tmp
    rpt.RecordSource = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_7_" & ChrW(1058) & _
        ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "_" & _
        ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081)
    rpt.Caption = ChrW(1058) & ChrW(1072) & ChrW(1073) & ChrW(1077) & ChrW(1083) & ChrW(1100) & " " & ChrW(1091) & _
        ChrW(1095) & ChrW(1077) & ChrW(1090) & ChrW(1072) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & _
        ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & " " & ChrW(1079) & _
        ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & ChrW(1081)
    rpt.Width = 9800
    grp = CreateGroupLevel(tmp, ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072), True, True)
    grp = CreateGroupLevel(tmp, ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & ChrW(1085) & _
        ChrW(1080) & ChrW(1082) & ChrW(1072), False, False)

    rpt.Section(acHeader).Height = 820
    rpt.Section(acHeader).BackColor = RGB(180, 83, 9)
    rpt.Section(acPageHeader).Height = 480
    rpt.Section(acPageHeader).BackColor = RGB(226, 232, 240)
    rpt.Section(acGroupLevel1Header).Height = 420
    rpt.Section(acGroupLevel1Header).BackColor = RGB(255, 251, 235)
    rpt.Section(acDetail).Height = 350
    rpt.Section(acGroupLevel1Footer).Height = 420
    rpt.Section(acFooter).Height = 4300
    rpt.Section(acFooter).BackColor = RGB(255, 255, 255)
    rpt.Section(acPageFooter).Height = 380

    AddReportLabel tmp, acHeader, ChrW(1058) & ChrW(1040) & ChrW(1041) & ChrW(1045) & ChrW(1051) & ChrW(1068) & " " & ChrW(1059) & _
        ChrW(1063) & ChrW(1045) & ChrW(1058) & ChrW(1040) & " " & ChrW(1055) & ChrW(1054) & ChrW(1057) & _
        ChrW(1045) & ChrW(1065) & ChrW(1040) & ChrW(1045) & ChrW(1052) & ChrW(1054) & ChrW(1057) & ChrW(1058) & _
        ChrW(1048) & " " & ChrW(1048) & " " & ChrW(1055) & ChrW(1056) & ChrW(1054) & ChrW(1055) & _
        ChrW(1059) & ChrW(1057) & ChrW(1050) & ChrW(1054) & ChrW(1042) & " " & ChrW(1047) & ChrW(1040) & _
        ChrW(1053) & ChrW(1071) & ChrW(1058) & ChrW(1048) & ChrW(1049), 200, 120, 9200, 360, 14, True, RGB(255, 255, 255)
    AddReportLabel tmp, acHeader, ChrW(1044) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1083) & ChrW(1080) & ChrW(1079) & ChrW(1072) & _
        ChrW(1094) & ChrW(1080) & ChrW(1103) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & _
        ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & " " & ChrW(1087) & ChrW(1086) & _
        " " & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1080) & _
        " (" & ChrW(1041) & "), " & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1084) & " (" & _
        ChrW(1059) & ") " & ChrW(1080) & " " & ChrW(1085) & ChrW(1077) & ChrW(1091) & ChrW(1074) & _
        ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & _
        ChrW(1099) & ChrW(1084) & " (" & ChrW(1053) & ") " & ChrW(1087) & ChrW(1088) & ChrW(1080) & _
        ChrW(1095) & ChrW(1080) & ChrW(1085) & ChrW(1072) & ChrW(1084), 200, 480, 9200, 250, 9, False, RGB(254, 243, 199)
    AddReportLabel tmp, acPageHeader, ChrW(1060) & ChrW(1048) & ChrW(1054) & " " & ChrW(1091) & ChrW(1095) & ChrW(1072) & ChrW(1097) & _
        ChrW(1077) & ChrW(1075) & ChrW(1086) & ChrW(1089) & ChrW(1103), 150, 90, 3300, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1059) & ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1086) & ChrW(1074), 3500, 90, 850, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & " " & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ".", 4400, 90, 1100, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1041) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1100), 5550, 90, 950, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1059) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ".", 6550, 90, 950, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1053) & ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ".", 7550, 90, 950, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1055) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ". %", 8550, 90, 1100, 280, 9, True, RGB(15, 23, 42)

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1050) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ": " & _
        ChrW(34) & " & [" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & _
        ChrW(1080) & ChrW(1077) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1072) & "]"
    AddReportText tmp, acGroupLevel1Header, strExpr, 150, 70, 4500, 280, 10, True, RGB(180, 83, 9), 1
    AddReportText tmp, acDetail, "[" & ChrW(1060) & ChrW(1048) & ChrW(1054) & "_" & ChrW(1091) & ChrW(1095) & ChrW(1077) & _
        ChrW(1085) & ChrW(1080) & ChrW(1082) & ChrW(1072) & "]", 150, 35, 3300, 270, 9, False, RGB(15, 23, 42), 1
    AddReportText tmp, acDetail, "[" & ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1091) & _
        ChrW(1088) & ChrW(1086) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "]", 3500, 35, 850, 270, 9, False, RGB(15, 23, 42), 2
    AddReportText tmp, acDetail, "[" & ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        "]", 4400, 35, 1100, 270, 9, True, RGB(194, 65, 12), 2
    AddReportText tmp, acDetail, "[" & ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & _
        ChrW(1079) & ChrW(1085) & ChrW(1080) & "]", 5550, 35, 950, 270, 9, False, RGB(15, 23, 42), 2
    AddReportText tmp, acDetail, "[" & ChrW(1059) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1093) & "]", 6550, 35, 950, 270, 9, False, RGB(15, 23, 42), 2
    AddReportText tmp, acDetail, "[" & ChrW(1053) & ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & ChrW(1078) & ChrW(1080) & _
        ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1093) & "]", 7550, 35, 950, 270, 9, False, RGB(220, 38, 38), 2
    strExpr = ""
    strExpr = strExpr & "=Format([" & ChrW(1055) & ChrW(1088) & ChrW(1086) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1090) & _
        "_" & ChrW(1087) & ChrW(1086) & ChrW(1089) & ChrW(1077) & ChrW(1097) & ChrW(1072) & ChrW(1077) & _
        ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & "]," & ChrW(34) & "0.0" & _
        ChrW(34) & ") & " & ChrW(34) & "%" & ChrW(34)
    AddReportText tmp, acDetail, strExpr, 8550, 35, 1100, 270, 9, False, RGB(15, 23, 42), 2

    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1048) & ChrW(1090) & ChrW(1086) & ChrW(1075) & ChrW(1086) & " " & _
        ChrW(1087) & ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & _
        ChrW(1091) & " " & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & _
        ChrW(1082) & ChrW(1086) & ChrW(1074) & ": " & ChrW(34) & " & Sum([" & ChrW(1042) & ChrW(1089) & _
        ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087)
    strExpr = strExpr & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & _
        "]) & " & ChrW(34) & " (" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & _
        ChrW(1085) & ChrW(1100) & ": " & ChrW(34) & " & Sum([" & ChrW(1055) & ChrW(1086) & "_" & _
        ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1080) & "]"
    strExpr = strExpr & ") & " & ChrW(34) & ", " & ChrW(1085) & ChrW(1077) & ChrW(1091) & ChrW(1074) & ChrW(1072) & _
        ChrW(1078) & ".: " & ChrW(34) & " & Sum([" & ChrW(1053) & ChrW(1077) & ChrW(1091) & ChrW(1074) & _
        ChrW(1072) & ChrW(1078) & ChrW(1080) & ChrW(1090) & ChrW(1077) & ChrW(1083) & ChrW(1100) & ChrW(1085) & _
        ChrW(1099) & ChrW(1093) & "]) & " & ChrW(34)
    strExpr = strExpr & ")" & ChrW(34)
    AddReportText tmp, acGroupLevel1Footer, strExpr, 150, 60, 8500, 280, 9, True, RGB(180, 83, 9), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1054) & ChrW(1041) & ChrW(1065) & ChrW(1045) & ChrW(1045) & " " & _
        ChrW(1063) & ChrW(1048) & ChrW(1057) & ChrW(1051) & ChrW(1054) & " " & ChrW(1055) & ChrW(1056) & _
        ChrW(1054) & ChrW(1055) & ChrW(1059) & ChrW(1057) & ChrW(1050) & ChrW(1054) & ChrW(1042) & " " & _
        ChrW(1055) & ChrW(1054) & " " & ChrW(1064) & ChrW(1050) & ChrW(1054) & ChrW(1051) & ChrW(1045) & _
        ": " & ChrW(34) & " & Sum([" & ChrW(1042) & ChrW(1089)
    strExpr = strExpr & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & _
        ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074) & "]) & " & ChrW(34) & " (" & _
        ChrW(1074) & " " & ChrW(1090) & "." & ChrW(1095) & ". " & ChrW(1087) & ChrW(1086) & _
        " " & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & ChrW(1080) & _
        ": " & ChrW(34) & " & S"
    strExpr = strExpr & "um([" & ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & _
        ChrW(1079) & ChrW(1085) & ChrW(1080) & "]) & " & ChrW(34) & ")" & ChrW(34)
    AddReportText tmp, acFooter, strExpr, 150, 100, 9200, 320, 11, True, RGB(180, 83, 9), 1

    AddReportBox tmp, acFooter, 150, 520, 9450, 3550, RGB(248, 250, 252), RGB(203, 213, 225)
    AddReportLabel tmp, acFooter, ChrW(1044) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084) & _
        ChrW(1072) & " " & ChrW(1088) & ChrW(1072) & ChrW(1089) & ChrW(1087) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1077) & ChrW(1083) & ChrW(1077) & ChrW(1085) & ChrW(1080) & ChrW(1103) & " " & _
        ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & _
        ChrW(1074) & " " & ChrW(1079) & ChrW(1072) & ChrW(1085) & ChrW(1103) & ChrW(1090) & ChrW(1080) & _
        ChrW(1081) & " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1082) & ChrW(1083) & ChrW(1072) & _
        ChrW(1089) & ChrW(1089) & ChrW(1072) & ChrW(1084) & " (" & ChrW(1086) & ChrW(1088) & ChrW(1072) & _
        ChrW(1085) & ChrW(1078) & ChrW(1077) & ChrW(1074) & ChrW(1099) & ChrW(1081) & " " & ChrW(8212) & _
        " " & ChrW(1074) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & ", " & ChrW(1089) & _
        ChrW(1080) & ChrW(1085) & ChrW(1080) & ChrW(1081) & " " & ChrW(8212) & " " & ChrW(1087) & _
        ChrW(1086) & " " & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & ChrW(1085) & _
        ChrW(1080) & ")", 350, 640, 8900, 300, 10, True, RGB(26, 54, 93)
    AddReportBox tmp, acFooter, 800, 1100, 8400, 2350, RGB(255, 255, 255), RGB(226, 232, 240)

    maxH = 6
    Set rs = db.OpenRecordset(ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_8_" & ChrW(1057) & _
        ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & _
        ChrW(1072) & "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1086) & _
        ChrW(1074))
    Do While Not rs.EOF
        If CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value) > maxH Then maxH = CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value)
        rs.MoveNext
    Loop
    rs.MoveFirst

    i = 0
    Do While Not rs.EOF And i < 6
        clsName = CStr(rs.Fields(ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1082) & ChrW(1083) & ChrW(1072) & ChrW(1089) & ChrW(1089) & ChrW(1072)).Value)
        absTotal = CLng(rs.Fields(ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1087) & ChrW(1088) & _
        ChrW(1086) & ChrW(1087) & ChrW(1091) & ChrW(1089) & ChrW(1082) & ChrW(1086) & ChrW(1074)).Value)
        absSick = CLng(rs.Fields(ChrW(1055) & ChrW(1086) & "_" & ChrW(1073) & ChrW(1086) & ChrW(1083) & ChrW(1077) & ChrW(1079) & _
        ChrW(1085) & ChrW(1080)).Value)
        xPos = 1150 + i * 1320
        barH = CLng((CDbl(absTotal) / CDbl(maxH)) * 1950)
        If barH < 80 And absTotal > 0 Then barH = 80
        If barH > 0 Then AddReportBox tmp, acFooter, xPos, 3450 - barH, 400, barH, RGB(234, 88, 12), RGB(234, 88, 12)
        AddReportLabel tmp, acFooter, CStr(absTotal), xPos + 90, 3450 - barH - 260, 320, 240, 8, True, RGB(194, 65, 12)
        barH = CLng((CDbl(absSick) / CDbl(maxH)) * 1950)
        If barH < 80 And absSick > 0 Then barH = 80
        If barH > 0 Then AddReportBox tmp, acFooter, xPos + 430, 3450 - barH, 380, barH, RGB(59, 130, 246), RGB(59, 130, 246)
        AddReportLabel tmp, acFooter, CStr(absSick), xPos + 510, 3450 - barH - 260, 320, 240, 8, False, RGB(29, 78, 216)
        AddReportLabel tmp, acFooter, clsName, xPos + 200, 3530, 600, 280, 9, True, RGB(30, 41, 59)
        i = i + 1
        rs.MoveNext
    Loop
    rs.Close

    AddReportText tmp, acPageFooter, "=Now()", 150, 60, 3500, 260, 8, False, RGB(100, 116, 139), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1057) & ChrW(1090) & ChrW(1088) & ". " & ChrW(34) & " & [Page] & " & _
        ChrW(34) & " " & ChrW(1080) & ChrW(1079) & " " & ChrW(34) & " & [Pages]"
    AddReportText tmp, acPageFooter, strExpr, 7200, 60, 2400, 260, 8, False, RGB(100, 116, 139), 3
    SaveAndRenameReport tmp, target
End Sub

Public Sub BuildReportSubjectsChart()
    Dim rpt As Report
    Dim tmp As String
    Dim target As String
    Dim db As Object
    Dim rs As Object
    Dim i As Long
    Dim barH As Long
    Dim xPos As Long
    Dim avgVal As Double
    Dim qualVal As Double
    Dim subjName As String
    Dim barColor As Long
    Dim strExpr As String

    target = ChrW(1054) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & "_4_" & ChrW(1057) & ChrW(1090) & _
        ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & ChrW(1082) & ChrW(1072) & _
        "_" & ChrW(1080) & "_" & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1087) & ChrW(1086) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & _
        ChrW(1084)
    SafeDeleteObject acReport, target
    Set db = CurrentDb
    Set rpt = CreateReport
    tmp = rpt.Name
    EnsureReportHeaderFooter rpt, tmp
    rpt.RecordSource = ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_4_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084)
    rpt.Caption = ChrW(1057) & ChrW(1090) & ChrW(1072) & ChrW(1090) & ChrW(1080) & ChrW(1089) & ChrW(1090) & ChrW(1080) & _
        ChrW(1082) & ChrW(1072) & " " & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & ChrW(1074) & _
        ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & ChrW(1080) & " " & _
        ChrW(1080) & " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & _
        ChrW(1084) & ChrW(1084) & ChrW(1072) & " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084)
    rpt.Width = 9800

    rpt.Section(acHeader).Height = 820
    rpt.Section(acHeader).BackColor = RGB(26, 54, 93)
    rpt.Section(acPageHeader).Height = 480
    rpt.Section(acPageHeader).BackColor = RGB(226, 232, 240)
    rpt.Section(acDetail).Height = 360
    rpt.Section(acFooter).Height = 4200
    rpt.Section(acFooter).BackColor = RGB(255, 255, 255)
    rpt.Section(acPageFooter).Height = 380

    AddReportLabel tmp, acHeader, ChrW(1057) & ChrW(1058) & ChrW(1040) & ChrW(1058) & ChrW(1048) & ChrW(1057) & ChrW(1058) & ChrW(1048) & _
        ChrW(1050) & ChrW(1040) & " " & ChrW(1050) & ChrW(1040) & ChrW(1063) & ChrW(1045) & ChrW(1057) & _
        ChrW(1058) & ChrW(1042) & ChrW(1040) & " " & ChrW(1047) & ChrW(1053) & ChrW(1040) & ChrW(1053) & _
        ChrW(1048) & ChrW(1049) & " " & ChrW(1048) & " " & ChrW(1044) & ChrW(1048) & ChrW(1040) & _
        ChrW(1043) & ChrW(1056) & ChrW(1040) & ChrW(1052) & ChrW(1052) & ChrW(1040) & " " & ChrW(1055) & _
        ChrW(1054) & " " & ChrW(1055) & ChrW(1056) & ChrW(1045) & ChrW(1044) & ChrW(1052) & ChrW(1045) & _
        ChrW(1058) & ChrW(1040) & ChrW(1052), 200, 120, 9200, 360, 14, True, RGB(255, 255, 255)
    AddReportLabel tmp, acHeader, ChrW(1057) & ChrW(1074) & ChrW(1086) & ChrW(1076) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & _
        ChrW(1072) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(1080) & ChrW(1090) & ChrW(1080) & ChrW(1095) & _
        ChrW(1077) & ChrW(1089) & ChrW(1082) & ChrW(1080) & ChrW(1081) & " " & ChrW(1086) & ChrW(1090) & _
        ChrW(1095) & ChrW(1077) & ChrW(1090) & " " & ChrW(1087) & ChrW(1086) & " " & ChrW(1088) & _
        ChrW(1077) & ChrW(1079) & ChrW(1091) & ChrW(1083) & ChrW(1100) & ChrW(1090) & ChrW(1072) & ChrW(1090) & _
        ChrW(1072) & ChrW(1084) & " " & ChrW(1090) & ChrW(1077) & ChrW(1082) & ChrW(1091) & ChrW(1097) & _
        ChrW(1077) & ChrW(1075) & ChrW(1086) & " " & ChrW(1082) & ChrW(1086) & ChrW(1085) & ChrW(1090) & _
        ChrW(1088) & ChrW(1086) & ChrW(1083) & ChrW(1103) & " " & ChrW(1091) & ChrW(1089) & ChrW(1087) & _
        ChrW(1077) & ChrW(1074) & ChrW(1072) & ChrW(1077) & ChrW(1084) & ChrW(1086) & ChrW(1089) & ChrW(1090) & _
        ChrW(1080), 200, 480, 9200, 250, 9, False, RGB(203, 213, 225)
    AddReportLabel tmp, acPageHeader, ChrW(1059) & ChrW(1095) & ChrW(1077) & ChrW(1073) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & _
        ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090), 150, 90, 2550, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082), 2750, 90, 850, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(171) & "5" & ChrW(187), 3650, 90, 650, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(171) & "4" & ChrW(187), 4350, 90, 650, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(171) & "3" & ChrW(187), 5050, 90, 650, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(171) & "2" & ChrW(187), 5750, 90, 650, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1057) & ChrW(1088) & ". " & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083), 6450, 90, 1100, 280, 9, True, RGB(15, 23, 42)
    AddReportLabel tmp, acPageHeader, ChrW(1050) & ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        " %", 7600, 90, 2000, 280, 9, True, RGB(15, 23, 42)

    AddReportText tmp, acDetail, "[" & ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & _
        ChrW(1077) & "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & _
        ChrW(1090) & ChrW(1072) & "]", 150, 40, 2550, 280, 9, True, RGB(15, 23, 42), 1
    AddReportText tmp, acDetail, "[" & ChrW(1042) & ChrW(1089) & ChrW(1077) & ChrW(1075) & ChrW(1086) & "_" & ChrW(1086) & _
        ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "]", 2750, 40, 850, 280, 9, False, RGB(15, 23, 42), 2
    AddReportText tmp, acDetail, "[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_5]", 3650, 40, 650, 280, 9, False, RGB(16, 185, 129), 2
    AddReportText tmp, acDetail, "[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_4]", 4350, 40, 650, 280, 9, False, RGB(37, 99, 235), 2
    AddReportText tmp, acDetail, "[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_3]", 5050, 40, 650, 280, 9, False, RGB(217, 119, 6), 2
    AddReportText tmp, acDetail, "[" & ChrW(1054) & ChrW(1094) & ChrW(1077) & ChrW(1085) & ChrW(1086) & ChrW(1082) & "_2]", 5750, 40, 650, 280, 9, False, RGB(220, 38, 38), 2
    strExpr = ""
    strExpr = strExpr & "=Format([" & ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083) & "]," & ChrW(34) & "0.00" & _
        ChrW(34) & ")"
    AddReportText tmp, acDetail, strExpr, 6450, 40, 1100, 280, 9, True, RGB(26, 54, 93), 2
    strExpr = ""
    strExpr = strExpr & "=Format([" & ChrW(1050) & ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & _
        ChrW(1086) & "_" & ChrW(1079) & ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & _
        "_" & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1094) & "]," & ChrW(34) & "0.0" & _
        ChrW(34) & ") & " & ChrW(34) & "%" & ChrW(34)
    AddReportText tmp, acDetail, strExpr, 7600, 40, 2000, 280, 9, True, RGB(15, 118, 110), 2

    AddReportBox tmp, acFooter, 150, 220, 9450, 3780, RGB(248, 250, 252), RGB(203, 213, 225)
    AddReportLabel tmp, acFooter, ChrW(1057) & ChrW(1090) & ChrW(1086) & ChrW(1083) & ChrW(1073) & ChrW(1095) & ChrW(1072) & ChrW(1090) & _
        ChrW(1072) & ChrW(1103) & " " & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & _
        ChrW(1072) & ChrW(1084) & ChrW(1084) & ChrW(1072) & ": " & ChrW(1057) & ChrW(1088) & ChrW(1077) & _
        ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & " " & ChrW(1073) & ChrW(1072) & ChrW(1083) & _
        ChrW(1083) & " " & ChrW(1080) & " " & ChrW(1082) & ChrW(1072) & ChrW(1095) & ChrW(1077) & _
        ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & " " & ChrW(1079) & ChrW(1085) & ChrW(1072) & _
        ChrW(1085) & ChrW(1080) & ChrW(1081) & " (%) " & ChrW(1087) & ChrW(1086) & " " & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084), 350, 340, 8900, 300, 10, True, RGB(26, 54, 93)
    AddReportBox tmp, acFooter, 750, 800, 8550, 2450, RGB(255, 255, 255), RGB(226, 232, 240)
    AddReportLabel tmp, acFooter, "5.0", 330, 740, 360, 240, 8, False, RGB(100, 116, 139)
    AddReportLabel tmp, acFooter, "4.0", 330, 1230, 360, 240, 8, False, RGB(100, 116, 139)
    AddReportLabel tmp, acFooter, "3.0", 330, 1720, 360, 240, 8, False, RGB(100, 116, 139)
    AddReportLabel tmp, acFooter, "0.0", 330, 3120, 360, 240, 8, False, RGB(100, 116, 139)

    Set rs = db.OpenRecordset(ChrW(1047) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1089) & "_4_" & ChrW(1057) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & ChrW(1073) & _
        ChrW(1072) & ChrW(1083) & ChrW(1083) & "_" & ChrW(1087) & ChrW(1086) & "_" & ChrW(1087) & _
        ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & ChrW(1072) & ChrW(1084))
    i = 0
    Do While Not rs.EOF And i < 8
        avgVal = CDbl(rs.Fields(ChrW(1057) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & _
        ChrW(1073) & ChrW(1072) & ChrW(1083) & ChrW(1083)).Value)
        qualVal = CDbl(rs.Fields(ChrW(1050) & ChrW(1072) & ChrW(1095) & ChrW(1077) & ChrW(1089) & ChrW(1090) & ChrW(1074) & ChrW(1086) & _
        "_" & ChrW(1079) & ChrW(1085) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1081) & "_" & _
        ChrW(1087) & ChrW(1088) & ChrW(1086) & ChrW(1094)).Value)
        subjName = CStr(rs.Fields(ChrW(1053) & ChrW(1072) & ChrW(1079) & ChrW(1074) & ChrW(1072) & ChrW(1085) & ChrW(1080) & ChrW(1077) & _
        "_" & ChrW(1087) & ChrW(1088) & ChrW(1077) & ChrW(1076) & ChrW(1084) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072)).Value)
        If Len(subjName) > 9 Then subjName = Left(subjName, 8) & "."
        barH = CLng(avgVal * 460)
        xPos = 960 + i * 1030
        If avgVal >= 4.5 Then
            barColor = RGB(16, 185, 129)
        ElseIf avgVal >= 4# Then
            barColor = RGB(37, 99, 235)
        Else
            barColor = RGB(245, 158, 11)
        End If
        AddReportBox tmp, acFooter, xPos, 3250 - barH, 640, barH, barColor, barColor
        AddReportLabel tmp, acFooter, Format(avgVal, "0.00"), xPos + 70, 3250 - barH - 250, 560, 230, 8, True, RGB(15, 23, 42)
        AddReportLabel tmp, acFooter, subjName, xPos - 40, 3310, 780, 260, 8, True, RGB(30, 41, 59)
        AddReportLabel tmp, acFooter, CStr(Round(qualVal, 0)) & "%", xPos + 80, 3580, 540, 240, 8, False, RGB(100, 116, 139)
        i = i + 1
        rs.MoveNext
    Loop
    rs.Close

    AddReportText tmp, acPageFooter, "=Now()", 150, 60, 3500, 260, 8, False, RGB(100, 116, 139), 1
    strExpr = ""
    strExpr = strExpr & "=" & ChrW(34) & ChrW(1057) & ChrW(1090) & ChrW(1088) & ". " & ChrW(34) & " & [Page] & " & _
        ChrW(34) & " " & ChrW(1080) & ChrW(1079) & " " & ChrW(34) & " & [Pages]"
    AddReportText tmp, acPageFooter, strExpr, 7200, 60, 2400, 260, 8, False, RGB(100, 116, 139), 3
    SaveAndRenameReport tmp, target
End Sub

Private Sub SetStartupProperty(ByVal propName As String, ByVal propType As Long, ByVal propVal As Variant)
    Dim db As Object
    Dim prp As Object
    Set db = CurrentDb
    On Error Resume Next
    db.Properties(propName) = propVal
    If Err.Number = 3270 Then
        Err.Clear
        Set prp = db.CreateProperty(propName, propType, propVal)
        db.Properties.Append prp
    End If
    On Error GoTo 0
End Sub

Public Sub BuildSchoolJournalDB(Optional ByVal blnSilent As Boolean = False)
    Dim strMsg As String
    Application.Echo False
    On Error GoTo ErrHandler

    BuildAllQueries
    BuildSubformStudents
    BuildSubformGrades
    BuildFormClasses
    BuildFormJournal
    BuildFormTeachers
    BuildFormAnalytics
    BuildFormMain

    BuildReportClassLists
    BuildReportStudentAverages
    BuildReportAttendance
    BuildReportSubjectsChart

    SetStartupProperty "AppTitle", 10, ChrW(1040) & ChrW(1048) & ChrW(1057) & " " & ChrW(171) & ChrW(1064) & ChrW(1082) & ChrW(1086) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(187)
    SetStartupProperty "StartUpForm", 10, ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1043) & ChrW(1083) & _
        ChrW(1072) & ChrW(1074) & ChrW(1085) & ChrW(1072) & ChrW(1103)

    Application.Echo True
    Application.RefreshDatabaseWindow
    DoCmd.OpenForm ChrW(1060) & ChrW(1086) & ChrW(1088) & ChrW(1084) & ChrW(1072) & "_" & ChrW(1043) & ChrW(1083) & _
        ChrW(1072) & ChrW(1074) & ChrW(1085) & ChrW(1072) & ChrW(1103), acNormal

    If Not blnSilent Then
        strMsg = ""
        strMsg = strMsg & ChrW(1043) & ChrW(1086) & ChrW(1090) & ChrW(1086) & ChrW(1074) & ChrW(1086) & "! " & ChrW(1042) & _
        ChrW(1089) & ChrW(1077) & " 8 " & ChrW(1079) & ChrW(1072) & ChrW(1087) & ChrW(1088) & ChrW(1086) & _
        ChrW(1089) & ChrW(1086) & ChrW(1074) & ", 7 " & ChrW(1092) & ChrW(1086) & ChrW(1088) & ChrW(1084) & _
        " " & ChrW(1080) & " 4 " & ChrW(1086) & ChrW(1090) & ChrW(1095) & ChrW(1077) & ChrW(1090) & _
        ChrW(1072) & " (" & ChrW(1089) & " "
        strMsg = strMsg & ChrW(1076) & ChrW(1080) & ChrW(1072) & ChrW(1075) & ChrW(1088) & ChrW(1072) & ChrW(1084) & ChrW(1084) & _
        ChrW(1072) & ChrW(1084) & ChrW(1080) & ") " & ChrW(1091) & ChrW(1089) & ChrW(1087) & ChrW(1077) & _
        ChrW(1096) & ChrW(1085) & ChrW(1086) & " " & ChrW(1089) & ChrW(1086) & ChrW(1079) & ChrW(1076) & _
        ChrW(1072) & ChrW(1085) & ChrW(1099) & " " & ChrW(1080) & " " & ChrW(1089) & ChrW(1086) & _
        ChrW(1093) & ChrW(1088) & ChrW(1072) & ChrW(1085) & ChrW(1077) & ChrW(1085) & ChrW(1099) & " " & _
        ChrW(1074) & " " & ChrW(1073) & ChrW(1072)
        strMsg = strMsg & ChrW(1079) & ChrW(1077) & " " & ChrW(1076) & ChrW(1072) & ChrW(1085) & ChrW(1085) & ChrW(1099) & _
        ChrW(1093) & " " & ChrW(171) & ChrW(1064) & ChrW(1082) & ChrW(1086) & ChrW(1083) & ChrW(1100) & _
        ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & ChrW(1088) & ChrW(1085) & _
        ChrW(1072) & ChrW(1083) & ChrW(187) & "!"
        MsgBox strMsg, vbInformation, ChrW(1040) & ChrW(1048) & ChrW(1057) & " " & ChrW(171) & ChrW(1064) & ChrW(1082) & ChrW(1086) & _
        ChrW(1083) & ChrW(1100) & ChrW(1085) & ChrW(1099) & ChrW(1081) & " " & ChrW(1078) & ChrW(1091) & _
        ChrW(1088) & ChrW(1085) & ChrW(1072) & ChrW(1083) & ChrW(187)
    End If
    Exit Sub

ErrHandler:
    Application.Echo True
    If Not blnSilent Then
        MsgBox "Error " & Err.Number & ": " & Err.Description, vbExclamation, "Builder Error"
    Else
        Err.Raise Err.Number, Err.Source, Err.Description
    End If
End Sub
